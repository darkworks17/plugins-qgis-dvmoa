import os
import re
import gc 
from qgis.core import (
    QgsProject, QgsPrintLayout, QgsLayoutItemMap, QgsLayoutExporter,
    QgsLayoutSize, QgsLayoutPoint, QgsUnitTypes, QgsRectangle,
    QgsFillSymbol, QgsRuleBasedRenderer, QgsLineSymbol,
    QgsExpression, QgsWkbTypes, QgsApplication, QgsFeatureRequest
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QIcon
# Se agregó QMenu a la importación
from PyQt5.QtWidgets import QInputDialog, QMessageBox, QAction, QProgressDialog, QApplication, QMenu

# ============================================
# FUNCIONES AUXILIARES
# ============================================
def obtener_capa_segura(nombre_capa):
    capas = QgsProject.instance().mapLayersByName(nombre_capa)
    return capas[0] if capas else None

def encontrar_campo(capa, lista_candidatos):
    if not capa: return None
    campos_reales = {f.name().upper(): f.name() for f in capa.fields()}
    for candidato in lista_candidatos:
        if candidato.upper() in campos_reales:
            return campos_reales[candidato.upper()]
    return None

def get_sql_condition(capa, campo, valor):
    # Condición de salida si viene vacío
    if not campo or valor is None or (isinstance(valor, str) and valor.strip() == ""): 
        return ""
        
    idx = capa.fields().indexOf(campo)
    es_numerico = idx != -1 and capa.fields().at(idx).isNumeric()
    
    # NUEVO: Si recibimos una lista (porque el usuario separó con comas)
    if isinstance(valor, list):
        if not valor: return ""
        if es_numerico:
            lista_vals = ", ".join(str(v) for v in valor)
        else:
            lista_vals = ", ".join(f"'{v}'" for v in valor)
        return f'"{campo}" IN ({lista_vals})'
        
    # LOGICA ORIGINAL: Si es un solo valor
    if es_numerico:
        return f'"{campo}" = {valor}'
    return f'"{campo}" = \'{valor}\''

# ============================================
# CLASE PRINCIPAL DEL PLUGIN
# ============================================
class ImagenAereaDVMOAPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dvmoa_menu = None # Variable para gestionar el menú superior
        self.OUTPUT_FOLDER = "C:/DVMOA/IMAGEN AEREA"

    def initGui(self):
        ruta_icono = os.path.join(os.path.dirname(__file__), "imagen_aerea_plugin.png")
        self.action = QAction(QIcon(ruta_icono), "Generar Imagen Aérea", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # --- LÓGICA DE MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        # Revisamos si el menú "&DVMOA" ya fue creado por otra de tus herramientas
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si no existe, lo creamos
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        # Agregamos nuestra acción a este menú principal
        self.dvmoa_menu.addAction(self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Removemos la acción del menú principal creado
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            # Si el menú se queda sin botones, lo eliminamos
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
                
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        parent = self.iface.mainWindow()
        layer = obtener_capa_segura("Predios")
        
        if not layer:
            QMessageBox.critical(parent, "Error", "❌ La capa 'Predios' no está cargada.")
            return

        # Capas de apoyo para resaltado
        capas_const = [lyr for lyr in QgsProject.instance().mapLayers().values() 
                      if lyr.name().startswith("Const_N") or lyr.name().startswith("Const_S") or lyr.name() == "Construcciones"]
        bardas_layer = obtener_capa_segura("Bardas")
        todas_las_capas_visuales = [layer] + capas_const
        if bardas_layer: todas_las_capas_visuales.append(bardas_layer)

        # --- SECCIÓN DE FILTROS ---
        filters = {}
        
        # 1. Realizó (Desplegable)
        c_per = encontrar_campo(layer, ["REALIZO", "USUARIO"])
        if c_per:
            vals = sorted([str(v).strip() for v in layer.uniqueValues(layer.fields().indexOf(c_per)) 
                           if v is not None and str(v).strip() != "" and str(v).upper() != "NULL"])
            sel, ok = QInputDialog.getItem(parent, "Filtro Personal", "Seleccione quien realizó:", ["(Todos)"] + vals, 0, False)
            if ok and sel != "(Todos)" and sel.strip() != "": 
                filters[c_per] = sel

        # 2. Estatus (Desplegable)
        c_est = encontrar_campo(layer, ["ESTATUS", "STATUS"])
        if c_est:
            vals = sorted([str(v).strip() for v in layer.uniqueValues(layer.fields().indexOf(c_est)) 
                           if v is not None and str(v).strip() != "" and str(v).upper() != "NULL"])
            sel, ok = QInputDialog.getItem(parent, "Filtro Estatus", "Seleccione Estatus:", ["(Todos)"] + vals, 0, False)
            if ok and sel != "(Todos)" and sel.strip() != "": 
                filters[c_est] = sel

        # 3. Filtros Manuales Inteligentes (Ignorando ceros a la izquierda y aceptando MULTIPLES opciones por comas)
        manuales = {"Municipio": ["MUNICIPIO"], "Zona": ["ZONA"], "Manzana": ["MANZANA"], "Predio": ["PREDIO"]}
        
        for label, cands in manuales.items():
            campo_enc = encontrar_campo(layer, cands)
            if campo_enc:
                val, ok = QInputDialog.getText(parent, f"Filtro: {label}", f"Ingrese {label}\n(Dejar en blanco para TODOS\nPuede separar varios con comas):")
                if ok:
                    # Si el usuario lo dejó en blanco, obviamos este filtro
                    if val.strip() == "":
                        continue 
                    
                    valores_limpios = []
                    # Separamos el texto ingresado usando comas
                    for v in val.split(','):
                        v_str = v.strip()
                        # Si ingresó números como "01", lo convertimos a "1"
                        if v_str.isdigit():
                            v_str = str(int(v_str))
                        if v_str:
                            valores_limpios.append(v_str)
                    
                    if not valores_limpios:
                        continue
                    
                    # Guardamos la lista si son varios, o el valor único si es uno solo
                    if len(valores_limpios) > 1:
                        filters[campo_enc] = valores_limpios
                    else:
                        filters[campo_enc] = valores_limpios[0]

        condiciones_base = [get_sql_condition(layer, k, v) for k, v in filters.items()]
        filter_expr_base = " AND ".join([c for c in condiciones_base if c])
        
        # Guardar estado original para restaurar al final
        estilos_originales = {lyr.id(): {'renderer': lyr.renderer().clone(), 'subset': lyr.subsetString()} 
                             for lyr in todas_las_capas_visuales}

        progress = None
        try:
            layer.setSubsetString(filter_expr_base)
            features = list(layer.getFeatures())
            if not features:
                QMessageBox.warning(parent, "Aviso", "No hay resultados con los filtros aplicados.")
                return

            os.makedirs(self.OUTPUT_FOLDER, exist_ok=True)
            campo_clave = encontrar_campo(layer, ["CLAVECATAS", "CLAVE"])
            
            # DIMENSIONES PAPEL A4 (297x210 mm)
            PAPEL_W, PAPEL_H = 297.0, 210.0
            RATIO_PAPEL = PAPEL_W / PAPEL_H

            # Ventana de progreso
            progress = QProgressDialog("Generando fotos aéreas...", "Cancelar Proceso", 0, len(features), parent)
            progress.setWindowTitle("Procesando Imágenes")
            progress.setWindowModality(Qt.WindowModal)
            progress.show()

            contador = 0
            for feat in features:
                if progress.wasCanceled(): break
                
                p_id = str(feat[campo_clave]) if campo_clave else str(feat.id())
                progress.setValue(contador)
                progress.setLabelText(f"Exportando {contador+1} de {len(features)}\nID: {p_id}")
                QApplication.processEvents() # Mantiene la interfaz viva

                layout = None
                try:
                    # 1. Resaltado Dinámico Temporal (Colores)
                    expr_id = get_sql_condition(layer, campo_clave, p_id)
                    
                    # Predio en Azul (Línea azul, sin relleno)
                    root_p = QgsRuleBasedRenderer.Rule(None)
                    rule_p = QgsRuleBasedRenderer.Rule(QgsFillSymbol.createSimple({'color': '0,0,0,0', 'outline_color': '0,0,255', 'outline_width': '1.0'}))
                    rule_p.setFilterExpression(expr_id)
                    root_p.appendChild(rule_p)
                    layer.setRenderer(QgsRuleBasedRenderer(root_p))
                    layer.triggerRepaint()

                    # Construcciones en Rojo
                    for c_lyr in capas_const:
                        c_campo = encontrar_campo(c_lyr, ["CLAVECATAS", "REF_PREDIO"])
                        root_c = QgsRuleBasedRenderer.Rule(None)
                        rule_c = QgsRuleBasedRenderer.Rule(QgsFillSymbol.createSimple({'color': '0,0,0,0', 'outline_color': '255,0,0', 'outline_width': '0.8'}))
                        if c_campo: rule_c.setFilterExpression(get_sql_condition(c_lyr, c_campo, p_id))
                        root_c.appendChild(rule_c)
                        c_lyr.setRenderer(QgsRuleBasedRenderer(root_c))
                        c_lyr.triggerRepaint()

                    # Bardas en Rojo
                    if bardas_layer:
                        b_campo = encontrar_campo(bardas_layer, ["CLAVECATAS", "CVE_CAT"])
                        root_b = QgsRuleBasedRenderer.Rule(None)
                        rule_b = QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({'line_color': '255,0,0', 'width': '0.8'}))
                        if b_campo: rule_b.setFilterExpression(get_sql_condition(bardas_layer, b_campo, p_id))
                        root_b.appendChild(rule_b)
                        bardas_layer.setRenderer(QgsRuleBasedRenderer(root_b))
                        bardas_layer.triggerRepaint()

                    # Forzamos a QGIS a actualizar los colores antes de tomar la foto
                    QApplication.processEvents()

                    # --- LÓGICA DE CENTRADO INTELIGENTE ---
                    bbox = feat.geometry().boundingBox()
                    centro = bbox.center()
                    w_geo, h_geo = bbox.width(), bbox.height()

                    if (w_geo / h_geo) > RATIO_PAPEL:
                        nueva_h = w_geo / RATIO_PAPEL; nueva_w = w_geo
                    else:
                        nueva_w = h_geo * RATIO_PAPEL; nueva_h = h_geo

                    # Zoom 1.4 para contexto aéreo
                    factor = 1.4
                    rect_final = QgsRectangle(
                        centro.x() - (nueva_w * factor) / 2.0, centro.y() - (nueva_h * factor) / 2.0,
                        centro.x() + (nueva_w * factor) / 2.0, centro.y() + (nueva_h * factor) / 2.0
                    )

                    # 2. Layout y Exportación
                    layout = QgsPrintLayout(QgsProject.instance())
                    layout.initializeDefaults()
                    layout.pageCollection().pages()[0].setPageSize(QgsLayoutSize(PAPEL_W, PAPEL_H, QgsUnitTypes.LayoutMillimeters))
                    
                    map_item = QgsLayoutItemMap(layout)
                    map_item.attemptMove(QgsLayoutPoint(0, 0, QgsUnitTypes.LayoutMillimeters))
                    map_item.attemptResize(QgsLayoutSize(PAPEL_W, PAPEL_H, QgsUnitTypes.LayoutMillimeters))
                    map_item.setExtent(rect_final)
                    layout.addLayoutItem(map_item)
                    
                    # Refrescar el mapa dentro del layout para asegurar que capte el azul y el rojo
                    map_item.refresh()

                    nombre_archivo = re.sub(r'[\\/*?:"<>|]', "_", p_id)
                    ruta = os.path.join(self.OUTPUT_FOLDER, f"{nombre_archivo}.jpg")
                    
                    exporter = QgsLayoutExporter(layout)
                    exporter.exportToImage(ruta, QgsLayoutExporter.ImageExportSettings())
                    
                except Exception as e_inner:
                    print(f"Error en {p_id}: {e_inner}")
                finally:
                    if layout:
                        QgsProject.instance().layoutManager().removeLayout(layout)

                contador += 1

            QMessageBox.information(parent, "Terminado", f"Generados: {contador} croquis\nCarpeta: {self.OUTPUT_FOLDER}")

        except Exception as e:
            QMessageBox.critical(parent, "Error Crítico", f"Se detuvo el proceso: {str(e)}")
        finally:
            # Restaurar Capas a su estado original (Estilos y Filtros)
            for lyr_id, original in estilos_originales.items():
                lyr = QgsProject.instance().mapLayer(lyr_id)
                if lyr:
                    lyr.setRenderer(original['renderer'])
                    lyr.setSubsetString(original['subset'])
                    lyr.triggerRepaint()
            if progress: progress.close()
            gc.collect()