def classFactory(iface):
    from .imagen_aerea_plugin import ImagenAereaDVMOAPlugin
    return ImagenAereaDVMOAPlugin(iface)
