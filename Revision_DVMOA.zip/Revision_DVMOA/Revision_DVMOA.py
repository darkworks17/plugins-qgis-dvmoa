import os
import pandas as pd
from qgis.core import (QgsProject, QgsSpatialIndex, QgsDistanceArea, 
                       QgsGeometry, QgsWkbTypes, NULL)
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QPushButton, 
                                 QLabel, QFileDialog, QMessageBox, QAction, QMenu)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.utils import iface

# --- CONFIGURACIÓN GLOBAL ---
EXCLUIDAS = ['APATERNO', 'AMATERNO', 'LADA', 'TELEFONO', 'ULTANIOPAG', 'fid', 'id', 'ogc_fid', 'RFC', 'CURP']
MARGEN = 0.05 

class Revision_DVMOA_Plugin:
    def __init__(self, iface):
        self.iface = iface
        self.panel = None
        self.action = None
        self.dvmoa_menu = None  # Variable para gestionar el menú superior

    def initGui(self):
        # Localizar el icono
        ruta_icono = os.path.join(os.path.dirname(__file__), "Revision_DVMOA.png")
        
        # Crear la acción para el menú
        self.action = QAction(
            QIcon(ruta_icono), 
            "Revisión DVMOA", 
            self.iface.mainWindow()
        )
        self.action.triggered.connect(self.run)

        # --- LÓGICA DE MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        # Revisamos si el menú "&DVMOA" ya fue creado por otra de tus herramientas
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si no existe, lo creamos en la barra principal
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        # Agregamos nuestra acción a este menú principal
        self.dvmoa_menu.addAction(self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Removemos la acción del menú principal creado
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            # Si el menú se queda sin botones, lo eliminamos
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
                
        self.iface.removeToolBarIcon(self.action)
        
        # Si el panel de revisión está abierto, lo cerramos al descargar el plugin
        if self.panel:
            self.panel.close()

    def run(self):
        # Si el panel ya está abierto, solo traerlo al frente
        if not self.panel:
            self.panel = InterfazRevision()
        self.panel.show()
        self.panel.raise_()
        self.panel.activateWindow()


# --- CLASE DE LA INTERFAZ (Tus 3 botones) ---
class InterfazRevision(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Revision_DVMOA')
        self.setFixedWidth(320)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        layout = QVBoxLayout()

        lbl = QLabel("Panel de Revisión DVMOA")
        lbl.setStyleSheet("font-weight: bold; font-size: 14px; margin: 5px; color: #1a2a6c;")
        lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(lbl)

        self.crear_boton(layout, "1. Predios_duplicados", "#3498db", self.revisar_predios)
        self.crear_boton(layout, "2. Frentes y Fondos", "#27ae60", self.revisar_frentes_fondos)
        self.crear_boton(layout, "3. Const_N", "#e67e22", self.revisar_construcciones)

        self.setLayout(layout)

    def crear_boton(self, layout, texto, color, funcion):
        btn = QPushButton(texto)
        btn.setStyleSheet(f"background-color: {color}; color: white; padding: 10px; font-weight: bold; border-radius: 4px;")
        btn.clicked.connect(funcion)
        layout.addWidget(btn)

    # --- AQUÍ VAN TUS FUNCIONES DE REVISIÓN (Mantenidas exactamente igual) ---
    def guardar_datos(self, datos, ruta, nombre_hoja="Errores"):
        df = pd.DataFrame(datos)
        try:
            import xlsxwriter
            writer = pd.ExcelWriter(ruta, engine='xlsxwriter')
            df.to_excel(writer, index=False, sheet_name=nombre_hoja)
            book = writer.book
            sheet = writer.sheets[nombre_hoja]
            rojo = book.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006'})
            sheet.conditional_format('A2:Z5000', {'type': 'text', 'criteria': 'containing', 'value': 'SI', 'format': rojo})
            sheet.conditional_format('A2:Z5000', {'type': 'text', 'criteria': 'containing', 'value': 'FALTA', 'format': rojo})
            writer.close()
        except:
            df.to_excel(ruta, index=False)

    def revisar_predios(self):
        try:
            capa = QgsProject.instance().mapLayersByName('Predios')[0]
        except: return QMessageBox.warning(self, "Aviso", "No se encontró la capa 'Predios'")
        
        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar Reporte", "", "Excel (*.xlsx)")
        if not ruta: return

        items = {f.id(): f for f in capa.getFeatures()}
        claves = [str(f['CLAVECATAS']).strip() for f in items.values()]
        dups = {x for x in claves if claves.count(x) > 1}
        idx = QgsSpatialIndex(capa.getFeatures())
        
        reporte, ids_sel = [], []
        campos = [f.name() for f in capa.fields() if f.name() not in EXCLUIDAS]

        for f_id, f in items.items():
            c16 = str(f['CLAVECATAS']).strip()
            es_carto = any(f.geometry().equals(items[cid].geometry()) for cid in idx.intersects(f.geometry().boundingBox()) if cid != f_id)
            v_fila = [c for c in campos if f[c] == NULL or str(f[c]).strip() == ""]
            
            if c16 in dups or es_carto or v_fila:
                ids_sel.append(f_id)
                reporte.append({'CLAVE': c16, 'REPETIDO': 'SI' if c16 in dups else 'NO', 'ENCIMADO': 'SI' if es_carto else 'NO', 'CAMPOS_VACIOS': ", ".join(v_fila)})
        
        capa.selectByIds(ids_sel)
        self.guardar_datos(reporte, ruta, "Predios")
        QMessageBox.information(self, "Listo", "Revisión de Predios terminada.")

    def revisar_frentes_fondos(self):
        try:
            lf = QgsProject.instance().mapLayersByName('Frente_Predios')[0]
            lo = QgsProject.instance().mapLayersByName('Fondo_Predios')[0]
            lp = QgsProject.instance().mapLayersByName('Predios')[0]
        except: return QMessageBox.warning(self, "Aviso", "Capas faltantes.")

        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar Reporte", "", "Excel (*.xlsx)")
        if not ruta: return

        predios_dict = {str(f['CLAVECATAS'])[:10]: f for f in lp.getFeatures()}
        vistos_f, vistos_o, reporte = set(), set(), []
        medidor = QgsDistanceArea()
        medidor.setEllipsoid(QgsProject.instance().ellipsoid())

        def revisar_l(lyr, col_val, set_v):
            sel = []
            for f in lyr.getFeatures():
                c10 = str(f['CVE_PRE'])[:10]
                geom = f.geometry()
                match, pos, medida = 'NO', 'NO', 'NO'
                if c10 in predios_dict:
                    match = 'SI'; set_v.add(c10)
                    borde = predios_dict[c10].geometry().convertToType(QgsWkbTypes.LineGeometry)
                    if geom.distance(borde) > MARGEN: pos = 'SI (FUERA)'
                    try: 
                        val_t = float(f[col_val] or 0)
                        if abs(medidor.measureLength(geom) - val_t) > MARGEN: medida = 'SI'
                    except: medida = 'SI (ERROR DATO)'
                if match == 'NO' or pos != 'NO' or medida != 'NO':
                    sel.append(f.id())
                    reporte.append({'CAPA': lyr.name(), 'ID_10': c10, 'EXISTE': match, 'UBICACION': pos, 'MEDIDA_MAL': medida, 'FALTA_DIBUJO': 'NO'})
            lyr.selectByIds(sel)

        revisar_l(lf, 'FRENTE', vistos_f)
        revisar_l(lo, 'FONDO', vistos_o)

        ids_p_malos = []
        for f_p in lp.getFeatures():
            c10 = str(f_p['CLAVECATAS'])[:10]
            f_f, f_o = c10 not in vistos_f, c10 not in vistos_o
            if f_f or f_o:
                ids_p_malos.append(f_p.id())
                msj = "FALTA FRENTE Y FONDO" if f_f and f_o else ("FALTA FRENTE" if f_f else "FALTA FONDO")
                reporte.append({'CAPA': 'Predios', 'ID_10': c10, 'EXISTE': 'SI', 'FALTA_DIBUJO': msj})
        
        lp.selectByIds(ids_p_malos)
        self.guardar_datos(reporte, ruta, "Frentes_Fondos")
        QMessageBox.information(self, "Listo", "Revisión de líneas terminada.")

    def revisar_construcciones(self):
        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar Reporte", "", "Excel (*.xlsx)")
        if not ruta: return
        hojas = {}
        for i in range(1, 11):
            capas = QgsProject.instance().mapLayersByName(f'Const_N{i}')
            if not capas: continue
            lyr = capas[0]
            campos = [fd.name() for fd in lyr.fields() if fd.name() not in EXCLUIDAS]
            err, ids = [], []
            for f in lyr.getFeatures():
                v = [c for c in campos if f[c] == NULL or str(f[c]).strip() == ""]
                if v:
                    d = dict(zip([fd.name() for fd in lyr.fields()], f.attributes()))
                    d['VACIOS_DETALLE'] = ", ".join(v)
                    err.append(d); ids.append(f.id())
            if err:
                hojas[lyr.name()] = pd.DataFrame(err)
                lyr.selectByIds(ids)
        if hojas:
            with pd.ExcelWriter(ruta) as writer:
                for n, df in hojas.items(): df.to_excel(writer, sheet_name=n, index=False)
            QMessageBox.information(self, "Listo", "Revisión de niveles terminada.")