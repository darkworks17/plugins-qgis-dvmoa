import os
from qgis.core import (QgsProject, QgsSpatialIndex, QgsDistanceArea, 
                       QgsGeometry, QgsWkbTypes, NULL)
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QPushButton, 
                                 QLabel, QFileDialog, QMessageBox, QAction, QMenu)
# Importamos QDate y QDateTime para formatear las fechas correctamente
from qgis.PyQt.QtCore import Qt, QDate, QDateTime
from qgis.PyQt.QtGui import QIcon
from qgis.utils import iface

# ==============================================================================
# LIBRERÍA
# ==============================================================================
try:
    import xlsxwriter
except ImportError:
    if iface:
        msg = (
            "Falta la librería 'xlsxwriter' en este equipo.\n\n"
            "Para que la herramienta funcione, abra 'OSGeo4W Shell' y ejecute:\n\n"
            "pip install xlsxwriter\n\n"
            "Después, vuelva a abrir QGIS."
        )
        QMessageBox.critical(iface.mainWindow(), "Requisito Faltante", msg)
    raise Exception("Librería xlsxwriter no instalada.")

# --- CONFIGURACIÓN GLOBAL ---
EXCLUIDAS = ['APATERNO', 'AMATERNO', 'LADA', 'TELEFONO', 'ULTANIOPAG', 'fid', 'id', 'ogc_fid', 'RFC', 'CURP']
MARGEN = 0.05 

class Revision_DVMOA_Plugin:
    def __init__(self, iface):
        self.iface = iface
        self.panel = None
        self.action = None
        self.dvmoa_menu = None  

    def initGui(self):
        ruta_icono = os.path.join(os.path.dirname(__file__), "Revision_DVMOA.png")
        
        self.action = QAction(
            QIcon(ruta_icono), 
            "Reporte DVMOA", 
            self.iface.mainWindow()
        )
        self.action.triggered.connect(self.run)

        # --- LÓGICA DE MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        self.dvmoa_menu.addAction(self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
                
        self.iface.removeToolBarIcon(self.action)
        
        if self.panel:
            self.panel.close()

    def run(self):
        if not self.panel:
            self.panel = InterfazRevision()
        self.panel.show()
        self.panel.raise_()
        self.panel.activateWindow()


# --- CLASE DE LA INTERFAZ ---
class InterfazRevision(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Reporte_DVMOA')
        self.setFixedWidth(320)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        layout = QVBoxLayout()

        lbl = QLabel("Panel de Revisión DVMOA")
        lbl.setStyleSheet("font-weight: bold; font-size: 14px; margin: 5px; color: #1a2a6c;")
        lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(lbl)

        self.crear_boton(layout, "1. Predios", "#3498db", self.revisar_predios)
        self.crear_boton(layout, "2. Frentes y Fondos", "#27ae60", self.revisar_frentes_fondos)
        self.crear_boton(layout, "3. Construcciones", "#e67e22", self.revisar_construcciones)

        self.setLayout(layout)

    def crear_boton(self, layout, texto, color, funcion):
        btn = QPushButton(texto)
        btn.setStyleSheet(f"background-color: {color}; color: white; padding: 10px; font-weight: bold; border-radius: 4px;")
        btn.clicked.connect(funcion)
        layout.addWidget(btn)

    # --- FUNCIÓN AUXILIAR ---
    def obtener_metadatos(self, feature):
        """Extrae de forma segura Fecha, Quien Creó (REALIZO) y Quien Modificó (MODIFICO)"""
        meta = {'FECHACREAC': '', 'REALIZO': '', 'MODIFICO': ''}
        
        if not feature.isValid():
            return meta

        campos_feature = [f.name().upper() for f in feature.fields()]
        
        for campo_objetivo in meta.keys():
            if campo_objetivo in campos_feature:
                # Obtener el nombre exacto respetando mayúsculas/minúsculas originales
                orig_name = feature.fields().at(campos_feature.index(campo_objetivo)).name()
                idx = feature.fields().indexOf(orig_name)
                
                if idx != -1:
                    val = feature.attributes()[idx]
                    if val != NULL and val is not None:
                        # Si es un objeto de fecha de QGIS, lo formateamos bonito a dd/MM/yyyy
                        if isinstance(val, QDate) or isinstance(val, QDateTime):
                            meta[campo_objetivo] = val.toString("dd/MM/yyyy")
                        else:
                            texto = str(val).strip()
                            if texto.upper() != 'NULL' and texto != "":
                                meta[campo_objetivo] = texto
        return meta

    # --- GUARDADO EXCEL ---
    def guardar_datos(self, datos, ruta, nombre_hoja="Errores"):
        if not datos:
            QMessageBox.information(self, "Aviso", "No se encontraron registros para exportar.")
            return

        try:
            workbook = xlsxwriter.Workbook(ruta)
            sheet = workbook.add_worksheet(nombre_hoja)
            rojo = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006'})

            headers = list(datos[0].keys())
            for col_num, header in enumerate(headers):
                sheet.write(0, col_num, header)

            for row_num, fila_dict in enumerate(datos, start=1):
                for col_num, header in enumerate(headers):
                    val = fila_dict.get(header, "")
                    sheet.write(row_num, col_num, str(val) if val is not None else "")

            sheet.conditional_format('A2:Z5000', {'type': 'text', 'criteria': 'containing', 'value': 'SI', 'format': rojo})
            sheet.conditional_format('A2:Z5000', {'type': 'text', 'criteria': 'containing', 'value': 'FALTA', 'format': rojo})
            
            workbook.close()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Ocurrió un error al guardar el archivo:\n{e}")

    # --- 1. REVISIÓN DE PREDIOS ---
    def revisar_predios(self):
        try:
            capa = QgsProject.instance().mapLayersByName('Predios')[0]
        except: return QMessageBox.warning(self, "Aviso", "No se encontró la capa 'Predios'")
        
        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar Reporte", "", "Excel (*.xlsx)")
        if not ruta: return

        items = {f.id(): f for f in capa.getFeatures()}
        claves = [str(f['CLAVECATAS']).strip() for f in items.values()]
        dups = {x for x in claves if claves.count(x) > 1}
        idx = QgsSpatialIndex(capa.getFeatures())
        
        reporte, ids_sel = [], []
        campos = [f.name() for f in capa.fields() if f.name() not in EXCLUIDAS]

        for f_id, f in items.items():
            c16 = str(f['CLAVECATAS']).strip()
            es_carto = any(f.geometry().equals(items[cid].geometry()) for cid in idx.intersects(f.geometry().boundingBox()) if cid != f_id)
            v_fila = [c for c in campos if f[c] == NULL or str(f[c]).strip() == ""]
            
            if c16 in dups or es_carto or v_fila:
                ids_sel.append(f_id)
                meta = self.obtener_metadatos(f)
                
                reporte.append({
                    'CLAVE': c16, 
                    'FECHACREAC': meta['FECHACREAC'],
                    'REALIZO': meta['REALIZO'],
                    'MODIFICO': meta['MODIFICO'],
                    'REPETIDO': 'SI' if c16 in dups else 'NO', 
                    'ENCIMADO': 'SI' if es_carto else 'NO', 
                    'CAMPOS_VACIOS': ", ".join(v_fila)
                })
        
        capa.selectByIds(ids_sel)
        self.guardar_datos(reporte, ruta, "Predios")
        QMessageBox.information(self, "Listo", "Revisión de Predios terminada.")

    # --- 2. REVISIÓN DE FRENTES Y FONDOS ---
    def revisar_frentes_fondos(self):
        try:
            lf = QgsProject.instance().mapLayersByName('Frente_Predios')[0]
            lo = QgsProject.instance().mapLayersByName('Fondo_Predios')[0]
            lp = QgsProject.instance().mapLayersByName('Predios')[0]
        except: return QMessageBox.warning(self, "Aviso", "Capas faltantes.")

        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar Reporte", "", "Excel (*.xlsx)")
        if not ruta: return

        predios_dict = {str(f['CLAVECATAS'])[:10]: f for f in lp.getFeatures()}
        vistos_f, vistos_o, reporte = set(), set(), []
        medidor = QgsDistanceArea()
        medidor.setEllipsoid(QgsProject.instance().ellipsoid())

        def revisar_l(lyr, col_val, set_v):
            sel = []
            for f in lyr.getFeatures():
                # CVE_PRE o CLAVECATAS
                campo_clave = 'CVE_PRE' if f.fields().indexOf('CVE_PRE') != -1 else 'CLAVECATAS'
                c10 = str(f[campo_clave])[:10] if f.fields().indexOf(campo_clave) != -1 else ""
                
                geom = f.geometry()
                match, pos, medida = 'NO', 'NO', 'NO'
                
                c16_completa = ""
                meta_final = {'FECHACREAC': '', 'REALIZO': '', 'MODIFICO': ''}

                if c10 in predios_dict:
                    match = 'SI'
                    set_v.add(c10)
                    f_predio = predios_dict[c10]
                    c16_completa = str(f_predio['CLAVECATAS']).strip()
                    
                    borde = f_predio.geometry().convertToType(QgsWkbTypes.LineGeometry)
                    if geom.distance(borde) > MARGEN: pos = 'SI (FUERA)'
                    
                    try: 
                        val_t = float(f[col_val] or 0)
                        if abs(medidor.measureLength(geom) - val_t) > MARGEN: medida = 'SI'
                    except: medida = 'SI (ERROR DATO)'

                    # Combinar datos
                    meta_linea = self.obtener_metadatos(f)
                    meta_predio = self.obtener_metadatos(f_predio)
                    for k in meta_final.keys():
                        meta_final[k] = meta_linea[k] if meta_linea[k] else meta_predio[k]
                else:
                    # Si no encuentra el predio
                    meta_final = self.obtener_metadatos(f)
                
                if match == 'NO' or pos != 'NO' or medida != 'NO':
                    sel.append(f.id())
                    reporte.append({
                        'CAPA': lyr.name(), 
                        'CLAVECATAS_16': c16_completa,
                        'ID_10': c10, 
                        'FECHACREAC': meta_final['FECHACREAC'],
                        'REALIZO': meta_final['REALIZO'],
                        'MODIFICO': meta_final['MODIFICO'],
                        'EXISTE': match, 
                        'UBICACION': pos, 
                        'MEDIDA_MAL': medida, 
                        'FALTA_DIBUJO': 'NO'
                    })
            lyr.selectByIds(sel)

        revisar_l(lf, 'FRENTE', vistos_f)
        revisar_l(lo, 'FONDO', vistos_o)

        ids_p_malos = []
        for f_p in lp.getFeatures():
            c10 = str(f_p['CLAVECATAS'])[:10]
            f_f, f_o = c10 not in vistos_f, c10 not in vistos_o
            
            if f_f or f_o:
                ids_p_malos.append(f_p.id())
                msj = "FALTA FRENTE Y FONDO" if f_f and f_o else ("FALTA FRENTE" if f_f else "FALTA FONDO")
                meta_predio = self.obtener_metadatos(f_p)
                
                reporte.append({
                    'CAPA': 'Predios', 
                    'CLAVECATAS_16': str(f_p['CLAVECATAS']).strip(),
                    'ID_10': c10, 
                    'FECHACREAC': meta_predio['FECHACREAC'],
                    'REALIZO': meta_predio['REALIZO'],
                    'MODIFICO': meta_predio['MODIFICO'],
                    'EXISTE': 'SI', 
                    'UBICACION': 'NO',
                    'MEDIDA_MAL': 'NO',
                    'FALTA_DIBUJO': msj
                })
        
        lp.selectByIds(ids_p_malos)
        self.guardar_datos(reporte, ruta, "Frentes_Fondos")
        QMessageBox.information(self, "Listo", "Revisión de líneas terminada.")

    # --- 3. REVISIÓN DE CONSTRUCCIONES ---
    def revisar_construcciones(self):
        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar Reporte", "", "Excel (*.xlsx)")
        if not ruta: return
        hojas = {}

        # Cargar fechas y usuarios de la capa de Predios
        predios_meta = {}
        try:
            lp = QgsProject.instance().mapLayersByName('Predios')[0]
            for f in lp.getFeatures():
                predios_meta[str(f['CLAVECATAS']).strip()] = self.obtener_metadatos(f)
        except:
            pass

        TABLAS_CONSTRUCCIONES = [
            "Const_N1", "Const_N2", "Const_N3", "Const_N4", "Const_N5",
            "Const_N6", "Const_N7", "Const_N8", "Const_N9", "Const_N10",
            "Const_S1", "Const_S2", "Const_S3",
            "Bardas", "Marquesina", "Voladizos"
        ]

        for nombre_capa in TABLAS_CONSTRUCCIONES:
            capas = QgsProject.instance().mapLayersByName(nombre_capa)
            if not capas: continue
            
            lyr = capas[0]
            campos = [fd.name() for fd in lyr.fields() if fd.name() not in EXCLUIDAS]
            err, ids = [], []
            
            for f in lyr.getFeatures():
                v = [c for c in campos if f[c] == NULL or str(f[c]).strip() == ""]
                if v:
                    d = dict(zip([fd.name() for fd in lyr.fields()], f.attributes()))
                    
                    meta_cons = self.obtener_metadatos(f)
                    
                    # Predios mediante CLAVECATAS
                    c16 = str(f.attribute('CLAVECATAS')).strip() if f.fields().indexOf('CLAVECATAS') != -1 else ""
                    meta_predio = predios_meta.get(c16, {'FECHACREAC': '', 'REALIZO': '', 'MODIFICO': ''})
                    
                    d['FECHACREAC'] = meta_cons['FECHACREAC'] if meta_cons['FECHACREAC'] else meta_predio['FECHACREAC']
                    d['REALIZO'] = meta_cons['REALIZO'] if meta_cons['REALIZO'] else meta_predio['REALIZO']
                    d['MODIFICO'] = meta_cons['MODIFICO'] if meta_cons['MODIFICO'] else meta_predio['MODIFICO']
                    
                    d['VACIOS_DETALLE'] = ", ".join(v)
                    err.append(d)
                    ids.append(f.id())
            
            if err:
                hojas[lyr.name()] = err
                lyr.selectByIds(ids)
        
        if hojas:
            try:
                workbook = xlsxwriter.Workbook(ruta)
                rojo = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006'})

                for nombre_hoja, datos in hojas.items():
                    sheet = workbook.add_worksheet(nombre_hoja)
                    if datos:
                        headers = list(datos[0].keys())
                        for col_num, header in enumerate(headers):
                            sheet.write(0, col_num, header)

                        for row_num, fila_dict in enumerate(datos, start=1):
                            for col_num, header in enumerate(headers):
                                val = fila_dict.get(header, "")
                                sheet.write(row_num, col_num, str(val) if val is not None else "")

                        sheet.conditional_format('A2:Z5000', {'type': 'text', 'criteria': 'containing', 'value': 'SI', 'format': rojo})
                        sheet.conditional_format('A2:Z5000', {'type': 'text', 'criteria': 'containing', 'value': 'FALTA', 'format': rojo})
                
                workbook.close()
                QMessageBox.information(self, "Listo", "Revisión de construcciones terminada.")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"No se pudo guardar el archivo:\n{e}")
        else:
            QMessageBox.information(self, "Listo", "No se encontraron errores en las construcciones.")