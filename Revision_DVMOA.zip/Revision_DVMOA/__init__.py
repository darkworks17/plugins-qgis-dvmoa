def classFactory(iface):
    from .Revision_DVMOA import InterfazRevision
    return InterfazRevision(iface)
