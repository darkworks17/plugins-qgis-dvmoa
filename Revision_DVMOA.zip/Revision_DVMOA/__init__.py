def classFactory(iface):
    from .Revision_DVMOA import Revision_DVMOA_Plugin
    return Revision_DVMOA_Plugin(iface)
