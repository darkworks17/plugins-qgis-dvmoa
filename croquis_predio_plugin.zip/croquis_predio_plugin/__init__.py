def classFactory(iface):
    from .croquis_predio_plugin import CroquisPredioDVMOAPlugin
    return CroquisPredioDVMOAPlugin(iface)
