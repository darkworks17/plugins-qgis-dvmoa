import os
import gc
import re
from qgis.core import (
    QgsProject, QgsLayoutItemMap, QgsPrintLayout,
    QgsLayoutExporter, QgsLayoutPoint, QgsLayoutSize,
    QgsUnitTypes, QgsRectangle,
    QgsSingleSymbolRenderer, QgsSymbol, QgsWkbTypes,
    QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
    QgsVectorLayerSimpleLabeling, QgsProperty, QgsField,
    QgsVectorLayer, QgsFeature, QgsGeometry, QgsFeatureRequest,
    QgsApplication, Qgis 
)
from PyQt5.QtCore import QVariant, Qt
from PyQt5.QtGui import QColor, QIcon
from PyQt5.QtWidgets import QInputDialog, QMessageBox, QAction, QProgressDialog, QApplication

# ============================================
# FUNCIONES AUXILIARES
# ============================================
def encontrar_campo(capa, lista_candidatos):
    if not capa: return None
    campos_reales = {f.name().upper(): f.name() for f in capa.fields()}
    for candidato in lista_candidatos:
        if candidato.upper() in campos_reales:
            return campos_reales[candidato.upper()]
    return None

def get_sql_condition(capa, campo, valor):
    if not campo or valor is None or str(valor).strip() == "": return ""
    idx = capa.fields().indexOf(campo)
    if idx != -1 and capa.fields().at(idx).isNumeric():
        return f'"{campo}" = {valor}'
    return f'"{campo}" = \'{valor}\''

# ============================================
# CLASE PRINCIPAL DEL PLUGIN
# ============================================
class CroquisPredioDVMOAPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        # Parámetros originales
        self.UMBRAL_AREA_PEQUENA = 22.0
        self.TAMANO_TEXTO_NORMAL = 12
        self.TAMANO_TEXTO_CHICO = 8
        self.DISTANCIA_AGRUPACION = 1.5 
        self.OUTPUT_FOLDER = r"C:\DVMOA\CROQUIS DE PREDIO"
        # Colores del código origen
        self.COLORES_ORIGEN = {
            "Const_N7": (0, 128, 128), "Const_N6": (230, 110, 0), "Const_N5": (180, 20, 230),
            "Const_N4": (64, 180, 64), "Const_N3": (205, 204, 0), "Const_N2": (102, 51, 153),
            "Const_N1": (165, 66, 66), "Const_S1": (119, 136, 153), "Const_S2": (47, 79, 79),
            "Bardas":   (0, 0, 139)
        }

    def initGui(self):
        ruta_icono = os.path.join(os.path.dirname(__file__), "croquis_predio_plugin.png")
        self.action = QAction(QIcon(ruta_icono), "Generar Croquis de Predio", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&DVMOA", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("&DVMOA", self.action)
        self.iface.removeToolBarIcon(self.action)

    # --- FUNCIÓN DE ESTILO DEL CÓDIGO ORIGEN ---
    def estilo_borde_origen(self, capa, color_rgb):
        """Aplica el estilo exacto del código origen: Relleno transparente y borde de color"""
        capa.setLabelsEnabled(False)
        sym = QgsSymbol.defaultSymbol(capa.geometryType())
        if not sym: return
        sl = sym.symbolLayer(0)
        if capa.geometryType() == QgsWkbTypes.PolygonGeometry:
            sl.setBrushStyle(Qt.NoBrush) # Relleno transparente
            sl.setStrokeColor(QColor(*color_rgb))
            sl.setStrokeWidth(0.8) # Grosor estándar del origen
        else:
            sl.setColor(QColor(*color_rgb))
            sl.setWidth(0.8)
        capa.setRenderer(QgsSingleSymbolRenderer(sym))
        capa.triggerRepaint()

    def estilizar_etiquetas_temp(self, vl):
        sym = QgsSymbol.defaultSymbol(vl.geometryType())
        sym.symbolLayer(0).setSize(0)
        vl.setRenderer(QgsSingleSymbolRenderer(sym))
        settings = QgsPalLayerSettings()
        settings.fieldName = 'TXT'
        settings.enabled = True
        settings.placement = Qgis.LabelPlacement.OverPoint
        settings.priority = 10
        expr = f"if(\"AREA\" < {self.UMBRAL_AREA_PEQUENA}, {self.TAMANO_TEXTO_CHICO}, {self.TAMANO_TEXTO_NORMAL})"
        settings.dataDefinedProperties().setProperty(QgsPalLayerSettings.Size, QgsProperty.fromExpression(expr))
        fmt = QgsTextFormat()
        fmt.setNamedStyle("Bold")
        fmt.setColor(QColor(50, 50, 50))
        buf = QgsTextBufferSettings()
        buf.setEnabled(True)
        buf.setSize(0.8)
        buf.setColor(QColor("white"))
        fmt.setBuffer(buf)
        settings.setFormat(fmt)
        vl.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        vl.setLabelsEnabled(True)

    def run(self):
        parent = self.iface.mainWindow()
        predios_layers = QgsProject.instance().mapLayersByName("Predios")
        if not predios_layers:
            QMessageBox.critical(parent, "Error", "Capa 'Predios' no encontrada."); return
        predios = predios_layers[0]

        # ============================================
        # --- FILTROS (Dropdowns + Manuales ACTUALIZADOS) ---
        # ============================================
        filters = {}
        
        # 1. Realizó (Desplegable)
        c_realizo = encontrar_campo(predios, ["REALIZO", "USUARIO"])
        if c_realizo:
            vals = sorted([str(v).strip() for v in predios.uniqueValues(predios.fields().indexOf(c_realizo)) 
                           if v is not None and str(v).strip() != "" and str(v).upper() != "NULL"])
            sel, ok = QInputDialog.getItem(parent, "Realizó", "Seleccione:", ["(Todos)"] + vals, 0, False)
            if ok and sel != "(Todos)" and sel.strip() != "": 
                filters[c_realizo] = sel

        # 2. Estatus (Desplegable)
        c_estatus = encontrar_campo(predios, ["ESTATUS", "STATUS"])
        if c_estatus:
            vals = sorted([str(v).strip() for v in predios.uniqueValues(predios.fields().indexOf(c_estatus)) 
                           if v is not None and str(v).strip() != "" and str(v).upper() != "NULL"])
            sel, ok = QInputDialog.getItem(parent, "Estatus", "Seleccione:", ["(Todos)"] + vals, 0, False)
            if ok and sel != "(Todos)" and sel.strip() != "": 
                filters[c_estatus] = sel

        # 3. Filtros Manuales Inteligentes (Ignorando ceros a la izquierda)
        manuales = {"Municipio": ["MUNICIPIO"], "Zona": ["ZONA"], "Manzana": ["MANZANA"], "Predio": ["PREDIO"]}
        for lbl, cand in manuales.items():
            c_found = encontrar_campo(predios, cand)
            if c_found:
                val, ok = QInputDialog.getText(parent, f"Filtro: {lbl}", f"Ingrese {lbl}\n(Dejar en blanco para TODOS):")
                if ok:
                    val_limpio = val.strip()
                    if val_limpio == "":
                        continue
                    if val_limpio.isdigit():
                        val_limpio = str(int(val_limpio))
                    filters[c_found] = val_limpio

        condiciones_base = [get_sql_condition(predios, k, v) for k, v in filters.items()]
        filter_exp_base = " AND ".join([c for c in condiciones_base if c])
        # ============================================

        nombres_dibujo = ["Bardas", "Const_N7", "Const_N6", "Const_N5", "Const_N4", "Const_N3", "Const_N2", "Const_N1", "Const_S1", "Const_S2"]
        capas_dibujo = [QgsProject.instance().mapLayersByName(n)[0] for n in nombres_dibujo if QgsProject.instance().mapLayersByName(n)]
        
        # Guardar estado original completo (Estilos + Filtros + Etiquetas)
        estado_original = {c.id(): {'rend': c.renderer().clone(), 'subset': c.subsetString(), 'lab': c.labelsEnabled()} for c in [predios] + capas_dibujo}

        capa_puntos = None
        progress = None
        try:
            # APLICAR ESTILOS DEL CÓDIGO ORIGEN
            predios.setSubsetString(filter_exp_base)
            self.estilo_borde_origen(predios, (72, 118, 147)) # Azul predio
            # El origen a veces engrosaba más el predio:
            predios.renderer().symbol().symbolLayer(0).setStrokeWidth(1.2)

            for c in capas_dibujo:
                c.setSubsetString("")
                color = self.COLORES_ORIGEN.get(c.name(), (0,0,0))
                self.estilo_borde_origen(c, color)

            feats = list(predios.getFeatures())
            if not feats:
                QMessageBox.warning(parent, "Aviso", "No hay resultados con los filtros aplicados."); return

            progress = QProgressDialog("Generando etiquetas...", "Cancelar", 0, len(feats), parent)
            progress.setWindowModality(Qt.WindowModal)
            progress.show()

            # --- GENERADOR DE PUNTOS (LÓGICA ORIGINAL) ---
            vl = QgsVectorLayer("Point?crs=" + predios.crs().authid(), "Etiquetas_Temp", "memory")
            pr = vl.dataProvider()
            pr.addAttributes([QgsField("TXT", QVariant.String), QgsField("AREA", QVariant.Double), QgsField("REF", QVariant.String)])
            vl.updateFields()
            
            c_clave = encontrar_campo(predios, ["CLAVECATAS", "CLAVE", "CVE_CAT"])
            feats_pts = []
            for idx, f_p in enumerate(feats):
                if progress.wasCanceled(): raise Exception("Cancelado por usuario")
                progress.setValue(idx); QApplication.processEvents()
                geom_p = f_p.geometry(); clave_p = str(f_p[c_clave]); bbox = geom_p.boundingBox()
                raw_pts = []
                for c_d in capas_dibujo:
                    req = QgsFeatureRequest().setFilterRect(bbox)
                    for f_c in c_d.getFeatures(req):
                        inter = f_c.geometry().intersection(geom_p)
                        if not inter.isEmpty() and inter.area() > 0.001:
                            txt = f_c["CVECLASIF"] if "CVECLASIF" in [f.name() for f in c_d.fields()] else None
                            if txt: raw_pts.append({'pt': inter.pointOnSurface().asPoint(), 'txt': txt, 'area': f_c.geometry().area()})
                agrup = []
                for r in raw_pts:
                    add = False
                    for g in agrup:
                        if r['pt'].distance(g['pt']) < self.DISTANCIA_AGRUPACION:
                            if r['txt'] not in g['txts']: g['txts'].append(r['txt'])
                            g['area_min'] = min(g['area_min'], r['area']); add = True; break
                    if not add: agrup.append({'pt': r['pt'], 'txts': [r['txt']], 'area_min': r['area']})
                for g in agrup:
                    f_pt = QgsFeature(); f_pt.setGeometry(QgsGeometry.fromPointXY(g['pt']))
                    f_pt.setAttributes(["\n".join(g['txts']), g['area_min'], clave_p])
                    feats_pts.append(f_pt)
            pr.addFeatures(feats_pts)
            capa_puntos = vl
            QgsProject.instance().addMapLayer(capa_puntos, False)
            self.estilizar_etiquetas_temp(capa_puntos)

            # --- EXPORTACIÓN CON CENTRADO Y AISLAMIENTO ---
            MAP_W, MAP_H = 236.0, 166.0
            RATIO_PAPEL = MAP_W / MAP_H
            os.makedirs(self.OUTPUT_FOLDER, exist_ok=True)
            progress.setLabelText("Exportando imágenes...")
            progress.setMaximum(len(feats))
            
            total_gen = 0
            for i, f in enumerate(feats):
                if progress.wasCanceled(): break
                clave = str(f[c_clave])
                progress.setValue(i)
                progress.setLabelText(f"Exportando {i+1}/{len(feats)}\nID: {clave}")
                QApplication.processEvents()

                # Aislar (sin vecinos)
                predios.setSubsetString(get_sql_condition(predios, c_clave, clave))
                capa_puntos.setSubsetString(f"\"REF\" = '{clave}'")
                for c_d in capas_dibujo:
                    c_fld = encontrar_campo(c_d, ["CLAVECATAS", "REF_PREDIO"])
                    if c_fld: c_d.setSubsetString(get_sql_condition(c_d, c_fld, clave))
                    else: c_d.setSubsetString("1=0")

                # Centrado Proporcional
                bbox = f.geometry().boundingBox()
                centro = bbox.center()
                w_g, h_g = bbox.width(), bbox.height()
                if (w_g / h_g) > RATIO_PAPEL:
                    n_h = w_g / RATIO_PAPEL; n_w = w_g
                else:
                    n_w = h_g * RATIO_PAPEL; n_h = h_g
                rect_final = QgsRectangle(centro.x() - (n_w*1.3)/2, centro.y() - (n_h*1.3)/2,
                                         centro.x() + (n_w*1.3)/2, centro.y() + (n_h*1.3)/2)

                layout = QgsPrintLayout(QgsProject.instance())
                layout.initializeDefaults()
                map_item = QgsLayoutItemMap(layout)
                map_item.setLayers([capa_puntos] + capas_dibujo + [predios])
                map_item.attemptResize(QgsLayoutSize(MAP_W, MAP_H, QgsUnitTypes.LayoutMillimeters))
                map_item.attemptMove(QgsLayoutPoint(30, 20, QgsUnitTypes.LayoutMillimeters))
                map_item.setExtent(rect_final)
                layout.addLayoutItem(map_item)

                # ========================================================
                # PARCHE PARA EVITAR CROQUIS EN BLANCO EN OTRAS MÁQUINAS
                # ========================================================
                map_item.refresh() 
                QApplication.processEvents() 

                exporter = QgsLayoutExporter(layout)
                if exporter.exportToImage(os.path.join(self.OUTPUT_FOLDER, f"{clave}.jpg"), QgsLayoutExporter.ImageExportSettings()) == QgsLayoutExporter.Success:
                    total_gen += 1
                
                predios.setSubsetString(filter_exp_base) # Restaurar filtro base

            QMessageBox.information(parent, "Terminado", f"Generados: {total_gen}")

        except Exception as e:
            QMessageBox.critical(parent, "Error", str(e))
        finally:
            # RESTAURACIÓN COMPLETA (ESTILOS Y FILTROS ORIGINALES)
            if capa_puntos: QgsProject.instance().removeMapLayer(capa_puntos.id())
            for cid, st in estado_original.items():
                lyr = QgsProject.instance().mapLayer(cid)
                if lyr:
                    lyr.setRenderer(st['rend'])
                    lyr.setSubsetString(st['subset'])
                    lyr.setLabelsEnabled(st['lab'])
                    lyr.triggerRepaint()
            if progress: progress.close()
            gc.collect()