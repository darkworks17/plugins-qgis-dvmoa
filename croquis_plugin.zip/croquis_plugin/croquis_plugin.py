import os
import math
import gc 
import time
from qgis.core import (
    QgsProject, QgsLayoutItemMap, QgsPrintLayout,
    QgsLayoutExporter, QgsLayoutPoint, QgsLayoutSize,
    QgsUnitTypes, QgsRectangle,
    QgsSingleSymbolRenderer, QgsSymbol, QgsWkbTypes,
    QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
    QgsVectorLayerSimpleLabeling, QgsGeometry,
    QgsSpatialIndex, QgsFeature, QgsField, QgsPointXY, QgsVectorLayer,
    QgsProperty, QgsFeatureRequest, QgsExpression
)
from PyQt5.QtCore import QVariant, Qt 
from PyQt5.QtGui import QColor, QIcon
from PyQt5.QtWidgets import QInputDialog, QMessageBox, QProgressDialog, QApplication, QAction, QMenu

# --- CONFIGURACIÓN ---
DISTANCIA_RECUADRO = 22.0
DISTANCIA_LIMITE_FISICO = 6.0
LONGITUD_MINIMA_CARA = 12.0
TAMANO_TEXTO_CALLES = 15
TAMANO_TEXTO_LIMITES = 13
OUTPUT_FOLDER = r"C:\DVMOA\CROQUIS DE MANZANA"

# ============================================
# FUNCIONES AUXILIARES (Sin alteraciones)
# ============================================
def obtener_capa(nombre):
    capas = QgsProject.instance().mapLayersByName(nombre)
    return capas[0] if capas else None

def encontrar_campo(capa, lista_candidatos):
    if not capa: return None
    campos_reales = {f.name().upper(): f.name() for f in capa.fields()}
    for candidato in lista_candidatos:
        if candidato.upper() in campos_reales:
            return campos_reales[candidato.upper()]
    return None

def calcular_angulo(geom_linea):
    if geom_linea.isMultipart(): 
        col = geom_linea.asGeometryCollection()
        if not col: return 0
        puntos = col[0].asPolyline()
    else: 
        puntos = geom_linea.asPolyline()
    if len(puntos) < 2: return 0
    dx = puntos[-1].x() - puntos[0].x()
    dy = puntos[-1].y() - puntos[0].y()
    return math.degrees(math.atan2(dy, dx)) % 180 

def son_paralelas(angulo1, angulo2, tolerancia=30):
    diff = abs(angulo1 - angulo2)
    return diff < tolerancia or abs(diff - 180) < tolerancia

def normalizar_direccion_linea(geom):
    if geom.isEmpty(): return geom
    if geom.isMultipart():
        col = geom.asGeometryCollection()
        if not col: return geom
        puntos = col[0].asPolyline()
    else:
        puntos = geom.asPolyline()
    if len(puntos) < 2: return geom
    p_ini = puntos[0]
    p_fin = puntos[-1]
    if abs(p_fin.x() - p_ini.x()) > abs(p_fin.y() - p_ini.y()):
        if p_ini.x() > p_fin.x(): puntos.reverse() 
    else:
        if p_ini.y() > p_fin.y(): puntos.reverse() 
    return QgsGeometry.fromPolylineXY(puntos)

def desplazar_hacia_afuera(geom_linea, pt_centro_manzana, distancia):
    geom_simp = geom_linea.simplify(0.5)
    pts = geom_simp.asPolyline()
    if len(pts) < 2: return geom_linea
    p1, p2 = pts[0], pts[-1]
    dx = p2.x() - p1.x()
    dy = p2.y() - p1.y()
    L = math.hypot(dx, dy)
    if L == 0: return geom_linea
    nx1, ny1 = -dy/L, dx/L
    nx2, ny2 = dy/L, -nx2/L # Corrección menor interna de normal
    nx2, ny2 = dy/L, -dx/L
    c_seg = geom_simp.centroid().asPoint()
    vx = c_seg.x() - pt_centro_manzana.x()
    vy = c_seg.y() - pt_centro_manzana.y()
    if (nx1 * vx + ny1 * vy) > (nx2 * vx + ny2 * vy):
        nx, ny = nx1, ny1
    else:
        nx, ny = nx2, ny2
    new_p1 = QgsPointXY(p1.x() + nx * distancia, p1.y() + ny * distancia)
    new_p2 = QgsPointXY(p2.x() + nx * distancia, p2.y() + ny * distancia)
    return normalizar_direccion_linea(QgsGeometry.fromPolylineXY([new_p1, new_p2]))

# ============================================
# FUNCIONES DE ESTILO (Sin alteraciones)
# ============================================
def estilo_manzana_numero(capa):
    campo_manzana = encontrar_campo(capa, ["MANZANA", "CVE_MAN", "CLAVE_MANZANA"])
    if not campo_manzana: campo_manzana = "MANZANA" 
    settings = QgsPalLayerSettings()
    settings.fieldName = f"lpad(to_string(\"{campo_manzana}\"), 3, '0')"
    settings.isExpression = True 
    settings.enabled = True
    settings.placement = QgsPalLayerSettings.Horizontal
    settings.centroidWhole = True
    formato = QgsTextFormat()
    formato.setSize(28)
    formato.setColor(QColor("black"))
    buffer = QgsTextBufferSettings()
    buffer.setEnabled(True)
    buffer.setSize(1.5)
    buffer.setColor(QColor(255, 255, 255, 255))
    formato.setBuffer(buffer)
    settings.setFormat(formato)
    capa.setLabelsEnabled(True)
    capa.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    sym = QgsSymbol.defaultSymbol(QgsWkbTypes.PolygonGeometry)
    sym.symbolLayer(0).setStrokeColor(QColor("black"))
    sym.symbolLayer(0).setStrokeWidth(1.2)
    sym.symbolLayer(0).setBrushStyle(Qt.NoBrush) 
    capa.setRenderer(QgsSingleSymbolRenderer(sym))

def estilo_predio_negro_solido(capa):
    sym = QgsSymbol.defaultSymbol(QgsWkbTypes.PolygonGeometry)
    sym.symbolLayer(0).setStrokeColor(QColor("black"))
    sym.symbolLayer(0).setStrokeWidth(1.0)
    sym.symbolLayer(0).setBrushStyle(Qt.SolidPattern)
    sym.symbolLayer(0).setFillColor(QColor("black"))
    capa.setRenderer(QgsSingleSymbolRenderer(sym))
    capa.setLabelsEnabled(False) 

def estilo_capa_temporal(capa, t_calle, t_limite):
    settings = QgsPalLayerSettings()
    settings.fieldName = 'NOMBRE' 
    settings.enabled = True
    settings.placement = QgsPalLayerSettings.Line
    settings.placementFlags = QgsPalLayerSettings.OnLine
    settings.overrunDistance = 500.0  
    settings.mergeLines = True
    settings.displayAll = False 
    settings.obstacleSettings().setIsObstacle(False)
    settings.upsidedownLabels = QgsPalLayerSettings.Upright
    settings.dist = 0
    expr_tamano = f"CASE WHEN \"TIPO\" = 'LIMITE' THEN {t_limite} WHEN \"TIPO\" = 'CALLE_INTERIOR' THEN 9 ELSE {t_calle} END"
    settings.dataDefinedProperties().setProperty(QgsPalLayerSettings.Size, QgsProperty.fromExpression(expr_tamano))
    formato = QgsTextFormat()
    formato.setColor(QColor("black"))
    buffer = QgsTextBufferSettings()
    buffer.setEnabled(True)
    buffer.setSize(1.2)
    buffer.setColor(QColor("white"))
    formato.setBuffer(buffer)
    settings.setFormat(formato)
    capa.setLabelsEnabled(True)
    capa.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    sym = QgsSymbol.defaultSymbol(QgsWkbTypes.LineGeometry)
    sym.symbolLayer(0).setPenStyle(Qt.NoPen) 
    capa.setRenderer(QgsSingleSymbolRenderer(sym))

# ============================================
# CLASE DEL PLUGIN PARA MENÚ DVMOA
# ============================================
class CroquisManzanaPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dvmoa_menu = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'croquis_manzana.png')
        self.action = QAction(QIcon(icon_path), "Generar Croquis de Manzana", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        menu_bar = self.iface.mainWindow().menuBar()
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        self.dvmoa_menu.addAction(self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        predios = obtener_capa("Predios")
        manzanas = obtener_capa("Manzanas")
        ejes = obtener_capa("Ejes de linea")

        if not all([predios, manzanas, ejes]):
            QMessageBox.critical(self.iface.mainWindow(), "Error", "FALTAN CAPAS.")
            return

        campo_clave = encontrar_campo(predios, ["CLAVECATAS", "CLAVE", "CVE_CAT", "CVE_PREDIO", "ID_PREDIO"])
        if not campo_clave:
            QMessageBox.critical(self.iface.mainWindow(), "Error", "No se encontró la columna de Clave Catastral.")
            return

        try:
            filters = {}
            campo_usuario = encontrar_campo(predios, ["REALIZO", "MODIFICO", "USUARIO"])
            if campo_usuario:
                valores = sorted([str(v).strip() for v in predios.uniqueValues(predios.fields().indexOf(campo_usuario)) 
                               if v is not None and str(v).strip() != "" and str(v).upper() != "NULL"])
                if valores:
                    sel, ok = QInputDialog.getItem(self.iface.mainWindow(), "Filtro Personal", f"Seleccione {campo_usuario}:", ["(Todos)"] + valores, 0, False)
                    if ok and sel != "(Todos)" and sel.strip() != "": 
                        filters[campo_usuario] = [sel] 
            
            campo_estatus = encontrar_campo(predios, ["ESTATUS", "STATUS"])
            if campo_estatus:
                valores = sorted([str(v).strip() for v in predios.uniqueValues(predios.fields().indexOf(campo_estatus)) 
                               if v is not None and str(v).strip() != "" and str(v).upper() != "NULL"])
                if valores:
                    sel, ok = QInputDialog.getItem(self.iface.mainWindow(), "Filtro Estatus", f"Seleccione {campo_estatus}:", ["(Todos)"] + valores, 0, False)
                    if ok and sel != "(Todos)" and sel.strip() != "": 
                        filters[campo_estatus] = [sel] 

            manuales = {
                "Municipio": ["MUNICIPIO", "CVE_MUN"], 
                "Zona": ["ZONA", "CVE_ZON", "CVE_ZONA"], 
                "Manzana": ["MANZANA", "CVE_MAN", "CLAVE_MANZANA"], 
                "Predio": ["PREDIO", "CVE_PRE", "LOTE"]
            }
            
            for f_lbl, f_candidates in manuales.items():
                c_found = encontrar_campo(predios, f_candidates)
                if c_found:
                    texto_ayuda = f"Ingrese {f_lbl}\n(Separar con comas para múltiples. Ej: 1, 2, 5)\n(Dejar en blanco para TODOS):"
                    val, ok = QInputDialog.getText(self.iface.mainWindow(), f"Filtro: {f_lbl}", texto_ayuda)
                    if ok:
                        val_limpio = val.strip()
                        if val_limpio == "": continue
                        valores_multiples = [v.strip() for v in val_limpio.split(",") if v.strip()]
                        if valores_multiples:
                            filters[c_found] = valores_multiples

            condiciones = []
            for k, lista_valores in filters.items():
                sub_condiciones = []
                for v in lista_valores:
                    if v.isdigit():
                        sub_condiciones.append(f'("{k}" = {v} OR "{k}" = \'{v}\')')
                    else:
                        sub_condiciones.append(f'"{k}" = \'{v}\'')
                condicion_campo = " OR ".join(sub_condiciones)
                condiciones.append(f"({condicion_campo})")
            
            filter_expr = " AND ".join(condiciones)
            if filter_expr:
                req = QgsFeatureRequest(QgsExpression(filter_expr))
                feats_predios = list(predios.getFeatures(req))
            else:
                feats_predios = list(predios.getFeatures())

            os.makedirs(OUTPUT_FOLDER, exist_ok=True)
            if not feats_predios: raise Exception("No se encontraron predios con los filtros seleccionados.")
            
            index_manzanas = QgsSpatialIndex(manzanas.getFeatures())
            index_ejes = QgsSpatialIndex(ejes.getFeatures())
            campo_calle_ejes = encontrar_campo(ejes, ["CALLE", "NOMBRE", "VIALIDAD"])

            total = len(feats_predios)
            progress = QProgressDialog(f"Iniciando... (0 de {total})", "Cancelar Proceso", 0, total, self.iface.mainWindow())
            progress.setWindowTitle("Generando Croquis")
            progress.setWindowModality(Qt.WindowModal)
            progress.show()

            total_generados = 0
            for idx, f_predio in enumerate(feats_predios):
                if progress.wasCanceled(): break
                progress.setValue(idx)
                
                layout = mem_manzana = mem_predio = mem_calles = None
                clave = str(f_predio[campo_clave]) if f_predio[campo_clave] else f"Predio_{idx}"
                progress.setLabelText(f"Procesando predio {idx+1} de {total}\nClave: {clave}")
                QApplication.processEvents()
                    
                try:
                    geom_predio = f_predio.geometry()
                    if not geom_predio.isGeosValid(): geom_predio = geom_predio.makeValid()

                    ids = index_manzanas.intersects(geom_predio.boundingBox())
                    manzana_found = None
                    for mid in ids:
                        f_m = manzanas.getFeature(mid)
                        if f_m.geometry().intersects(geom_predio.pointOnSurface()):
                            manzana_found = f_m; break
                    
                    if not manzana_found: continue

                    geom_manzana = manzana_found.geometry()
                    pt_centro_manzana = geom_manzana.centroid().asPoint()

                    # EXTRACCIÓN A CAPAS VIRTUALES
                    mem_manzana = QgsVectorLayer(f"Polygon?crs={manzanas.crs().authid()}", "Mem_Manzana", "memory")
                    pr_m = mem_manzana.dataProvider()
                    pr_m.addAttributes(manzanas.fields())
                    mem_manzana.updateFields()
                    f_m_copy = QgsFeature(manzana_found)
                    pr_m.addFeatures([f_m_copy])
                    estilo_manzana_numero(mem_manzana)
                    QgsProject.instance().addMapLayer(mem_manzana, False)

                    mem_predio = QgsVectorLayer(f"Polygon?crs={predios.crs().authid()}", "Mem_Predio", "memory")
                    pr_p = mem_predio.dataProvider()
                    pr_p.addAttributes(predios.fields())
                    mem_predio.updateFields()
                    f_p_copy = QgsFeature(f_predio)
                    pr_p.addFeatures([f_p_copy])
                    estilo_predio_negro_solido(mem_predio)
                    QgsProject.instance().addMapLayer(mem_predio, False)

                    # --------------------------------------------------------
                    # 8. MANEJO DE CALLES Y LÍMITES (LÓGICA OPTIMIZADA IMAGEN 2)
                    # --------------------------------------------------------
                    geom_recuadro = geom_manzana.buffer(DISTANCIA_RECUADRO, 5)
                    feats_temporales = []
                    
                    contorno_manzana = geom_manzana.convertToType(QgsWkbTypes.LineGeometry)
                    if contorno_manzana.isMultipart():
                        col = contorno_manzana.asGeometryCollection()
                        if col: contorno_manzana = max(col, key=lambda g: g.length())
                    
                    pts_contorno = contorno_manzana.asPolyline()
                    
                    for i in range(len(pts_contorno) - 1):
                        seg_cara = QgsGeometry.fromPolylineXY([pts_contorno[i], pts_contorno[i+1]])
                        if seg_cara.length() < 2.0: continue
                        
                        zona_busqueda_cara = seg_cara.buffer(DISTANCIA_RECUADRO, 3)
                        ang_cara = calcular_angulo(seg_cara)
                        
                        candidatos_ejes = index_ejes.intersects(zona_busqueda_cara.boundingBox())
                        calle_encontrada_en_esta_cara = False
                        
                        for cid in candidatos_ejes:
                            f_eje = ejes.getFeature(cid)
                            nom = str(f_eje[campo_calle_ejes] or "").strip()
                            if not nom or nom.upper() == "NULL": continue
                            
                            g_eje = f_eje.geometry()
                            
                            if g_eje.distance(seg_cara) < DISTANCIA_RECUADRO:
                                g_recortada = g_eje.intersection(zona_busqueda_cara)
                                
                                if not g_recortada.isEmpty() and g_recortada.length() > 2.0:
                                    if son_paralelas(ang_cara, calcular_angulo(g_recortada), 40):
                                        ft = QgsFeature()
                                        ft.setGeometry(g_recortada)
                                        ft.setAttributes([nom, "CALLE"])
                                        feats_temporales.append(ft)
                                        calle_encontrada_en_esta_cara = True
                        
                        if not calle_encontrada_en_esta_cara and seg_cara.length() >= LONGITUD_MINIMA_CARA:
                            geom_limite = desplazar_hacia_afuera(seg_cara, pt_centro_manzana, DISTANCIA_LIMITE_FISICO)
                            ft_limite = QgsFeature()
                            ft_limite.setGeometry(geom_limite)
                            ft_limite.setAttributes(["LIMITE FISICO", "LIMITE"])
                            feats_temporales.append(ft_limite)

                    if feats_temporales:
                        mem_calles = QgsVectorLayer(f"LineString?crs={ejes.crs().authid()}", "Mem_Etiquetas", "memory")
                        pr = mem_calles.dataProvider()
                        pr.addAttributes([QgsField("NOMBRE", QVariant.String), QgsField("TIPO", QVariant.String)])
                        mem_calles.updateFields()
                        pr.addFeatures(feats_temporales)
                        estilo_capa_temporal(mem_calles, TAMANO_TEXTO_CALLES, TAMANO_TEXTO_LIMITES)
                        QgsProject.instance().addMapLayer(mem_calles, False)
                        capas_mapa = [mem_calles, mem_predio, mem_manzana]
                    else:
                        capas_mapa = [mem_predio, mem_manzana]

                    # COMPOSICIÓN DEL LAYOUT
                    layout = QgsPrintLayout(QgsProject.instance())
                    layout.initializeDefaults()
                    map_item = QgsLayoutItemMap(layout)
                    map_item.setFrameEnabled(False)
                    map_item.setLayers(capas_mapa)
                    map_item.attemptResize(QgsLayoutSize(300, 170, QgsUnitTypes.LayoutMillimeters))
                    map_item.attemptMove(QgsLayoutPoint(0, 0, QgsUnitTypes.LayoutMillimeters))
                    
                    bbox_base = geom_recuadro.boundingBox()
                    centro_mapa = bbox_base.center()
                    target_ratio = 300.0 / 170.0
                    w, h = bbox_base.width(), bbox_base.height()
                    if (w / h) > target_ratio:
                        nueva_w = w * 1.1 
                        nueva_h = nueva_w / target_ratio
                    else:
                        nueva_h = h * 1.1
                        nueva_w = nueva_h * target_ratio

                    rect_final = QgsRectangle(
                        centro_mapa.x() - nueva_w/2, centro_mapa.y() - nueva_h/2,
                        centro_mapa.x() + nueva_w/2, centro_mapa.y() + nueva_h/2
                    )
                    map_item.setExtent(rect_final)
                    layout.addLayoutItem(map_item)

                    # RENDERIZADO Y EXPORTACIÓN
                    map_item.invalidateCache()
                    layout.refresh()
                    QApplication.processEvents()
                    time.sleep(1.2) 
                    QApplication.processEvents()

                    exporter = QgsLayoutExporter(layout)
                    ruta_salida = os.path.join(OUTPUT_FOLDER, f"{clave}.jpg")
                    img_settings = QgsLayoutExporter.ImageExportSettings()
                    img_settings.dpi = 300
                    exporter.exportToImage(ruta_salida, img_settings)
                    total_generados += 1

                except Exception as e_inner:
                    print(f"Error en {clave}: {e_inner}")
                finally:
                    if mem_calles: QgsProject.instance().removeMapLayer(mem_calles.id())
                    if mem_predio: QgsProject.instance().removeMapLayer(mem_predio.id())
                    if mem_manzana: QgsProject.instance().removeMapLayer(mem_manzana.id())
                    if layout: QgsProject.instance().layoutManager().removeLayout(layout)

            progress.setValue(total)
            QMessageBox.information(self.iface.mainWindow(), "Terminado", f"Proceso finalizado.\nCroquis generados: {total_generados}")

        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "Error", str(e))
        finally:
            gc.collect()