import os
import math
import gc 
import traceback
from qgis.core import (
    QgsProject, QgsLayoutItemMap, QgsPrintLayout,
    QgsLayoutExporter, QgsLayoutPoint, QgsLayoutSize,
    QgsUnitTypes, QgsRectangle,
    QgsSingleSymbolRenderer, QgsSymbol, QgsWkbTypes,
    QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
    QgsVectorLayerSimpleLabeling, QgsGeometry,
    QgsSpatialIndex, QgsFeature, QgsField, QgsPointXY, QgsVectorLayer,
    QgsProperty 
)
from PyQt5.QtCore import QVariant, Qt 
from PyQt5.QtGui import QColor, QIcon
from PyQt5.QtWidgets import QInputDialog, QMessageBox, QProgressDialog, QApplication, QAction

# ======================
# FUNCIONES AUXILIARES 
# ======================
def obtener_capa(nombre):
    capas = QgsProject.instance().mapLayersByName(nombre)
    return capas[0] if capas else None

def encontrar_campo(capa, lista_candidatos):
    if not capa: return None
    campos_reales = {f.name().upper(): f.name() for f in capa.fields()}
    for candidato in lista_candidatos:
        if candidato.upper() in campos_reales:
            return campos_reales[candidato.upper()]
    return None

def obtener_valores_unicos(capa, nombre_campo):
    idx = capa.fields().indexOf(nombre_campo)
    if idx == -1: return []
    valores = capa.uniqueValues(idx)
    return sorted([str(v) for v in valores if v is not None and str(v).strip() != ""])

def calcular_angulo(geom_linea):
    if geom_linea.isMultipart(): 
        col = geom_linea.asGeometryCollection()
        if not col: return 0
        puntos = col[0].asPolyline()
    else: 
        puntos = geom_linea.asPolyline()
    if len(puntos) < 2: return 0
    dx = puntos[-1].x() - puntos[0].x()
    dy = puntos[-1].y() - puntos[0].y()
    return math.degrees(math.atan2(dy, dx)) % 180 

def son_paralelas(angulo1, angulo2, tolerancia=30):
    diff = abs(angulo1 - angulo2)
    return diff < tolerancia or abs(diff - 180) < tolerancia

def normalizar_direccion_linea(geom):
    if geom.isEmpty(): return geom
    if geom.isMultipart():
        col = geom.asGeometryCollection()
        if not col: return geom
        puntos = col[0].asPolyline()
    else:
        puntos = geom.asPolyline()
    if len(puntos) < 2: return geom
    p_ini = puntos[0]
    p_fin = puntos[-1]
    if abs(p_fin.x() - p_ini.x()) > abs(p_fin.y() - p_ini.y()):
        if p_ini.x() > p_fin.x(): puntos.reverse() 
    else:
        if p_ini.y() > p_fin.y(): puntos.reverse() 
    return QgsGeometry.fromPolylineXY(puntos)

def desplazar_hacia_afuera(geom_linea, pt_centro_manzana, distancia):
    geom_simp = geom_linea.simplify(0.5)
    pts = geom_simp.asPolyline()
    if len(pts) < 2: return geom_linea
    p1, p2 = pts[0], pts[-1]
    dx = p2.x() - p1.x()
    dy = p2.y() - p1.y()
    L = math.hypot(dx, dy)
    if L == 0: return geom_linea
    nx1, ny1 = -dy/L, dx/L
    nx2, ny2 = dy/L, -dx/L
    c_seg = geom_simp.centroid().asPoint()
    vx = c_seg.x() - pt_centro_manzana.x()
    vy = c_seg.y() - pt_centro_manzana.y()
    if (nx1 * vx + ny1 * vy) > (nx2 * vx + ny2 * vy):
        nx, ny = nx1, ny1
    else:
        nx, ny = nx2, ny2
    new_p1 = QgsPointXY(p1.x() + nx * distancia, p1.y() + ny * distancia)
    new_p2 = QgsPointXY(p2.x() + nx * distancia, p2.y() + ny * distancia)
    return normalizar_direccion_linea(QgsGeometry.fromPolylineXY([new_p1, new_p2]))

# ======================
# ESTILOS ESTÁNDAR 
# ======================
def estilo_manzana_numero(capa):
    campo_manzana = encontrar_campo(capa, ["MANZANA", "CVE_MAN", "CLAVE_MANZANA"])
    if not campo_manzana: campo_manzana = "MANZANA" 
    settings = QgsPalLayerSettings()
    settings.fieldName = f"lpad(to_string(\"{campo_manzana}\"), 3, '0')"
    settings.isExpression = True 
    settings.enabled = True
    settings.placement = QgsPalLayerSettings.Horizontal
    settings.centroidWhole = True
    formato = QgsTextFormat()
    formato.setSize(28)
    formato.setColor(QColor("black"))
    buffer = QgsTextBufferSettings()
    buffer.setEnabled(True)
    buffer.setSize(1.5)
    buffer.setColor(QColor(255, 255, 255, 255))
    formato.setBuffer(buffer)
    settings.setFormat(formato)
    capa.setLabelsEnabled(True)
    capa.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    sym = QgsSymbol.defaultSymbol(QgsWkbTypes.PolygonGeometry)
    sym.symbolLayer(0).setStrokeColor(QColor("black"))
    sym.symbolLayer(0).setStrokeWidth(1.2)
    sym.symbolLayer(0).setBrushStyle(Qt.NoBrush) 
    capa.setRenderer(QgsSingleSymbolRenderer(sym))

def estilo_predio_negro_solido(capa):
    sym = QgsSymbol.defaultSymbol(QgsWkbTypes.PolygonGeometry)
    sym.symbolLayer(0).setStrokeColor(QColor("black"))
    sym.symbolLayer(0).setStrokeWidth(1.0)
    sym.symbolLayer(0).setBrushStyle(Qt.SolidPattern)
    sym.symbolLayer(0).setFillColor(QColor("black"))
    capa.setRenderer(QgsSingleSymbolRenderer(sym))
    capa.setLabelsEnabled(False) 

def estilo_capa_temporal(capa, t_calle, t_limite):
    settings = QgsPalLayerSettings()
    settings.fieldName = 'NOMBRE' 
    settings.enabled = True
    settings.placement = QgsPalLayerSettings.Line
    settings.placementFlags = QgsPalLayerSettings.OnLine
    settings.upsidedownLabels = QgsPalLayerSettings.Upright
    settings.mergeLines = True
    settings.displayAll = False 
    settings.dist = 0
    expr_tamano = f"IF(\"TIPO\" = 'LIMITE', {t_limite}, {t_calle})"
    settings.dataDefinedProperties().setProperty(QgsPalLayerSettings.Size, QgsProperty.fromExpression(expr_tamano))
    formato = QgsTextFormat()
    formato.setColor(QColor("black"))
    buffer = QgsTextBufferSettings()
    buffer.setEnabled(True)
    buffer.setSize(1.2)
    buffer.setColor(QColor("white"))
    formato.setBuffer(buffer)
    settings.setFormat(formato)
    capa.setLabelsEnabled(True)
    capa.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    sym = QgsSymbol.defaultSymbol(QgsWkbTypes.LineGeometry)
    sym.symbolLayer(0).setPenStyle(Qt.NoPen) 
    capa.setRenderer(QgsSingleSymbolRenderer(sym))

# ==========================================
# CLASE PRINCIPAL DEL PLUGIN
# ==========================================
class CroquisDVMOAPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.DISTANCIA_RECUADRO = 22.0
        self.DISTANCIA_LIMITE_FISICO = 6.0
        self.LONGITUD_MINIMA_CARA = 12.0
        self.TAMANO_TEXTO_CALLES = 15
        self.TAMANO_TEXTO_LIMITES = 13
        self.OUTPUT_FOLDER = r"C:\DVMOA\CROQUIS DE MANZANA"

    def initGui(self):
        ruta_icono = os.path.join(os.path.dirname(__file__), "croquis_plugin.png")
        self.action = QAction(QIcon(ruta_icono), "Generar Croquis de Manzana", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&DVMOA", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("&DVMOA", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        predios = obtener_capa("Predios")
        manzanas = obtener_capa("Manzanas")
        ejes = obtener_capa("Ejes de linea")
        estado_original = {}

        if not all([predios, manzanas, ejes]):
            QMessageBox.critical(self.iface.mainWindow(), "Error", "❌ FALTAN CAPAS.\nAsegúrese de tener abiertas: Predios, Manzanas y Ejes de linea.")
            return

        # VALIDACIÓN CRÍTICA: Asegurar que encontramos la columna clave antes de continuar
        campo_clave = encontrar_campo(predios, ["CLAVECATAS", "CLAVE", "CVE_CAT", "CVE_PREDIO", "ID_PREDIO"])
        if not campo_clave:
            QMessageBox.critical(self.iface.mainWindow(), "Error de Columnas", "❌ No se encontró la columna de Clave Catastral en la capa Predios.\nVerifica que exista una columna llamada CLAVECATAS, CLAVE, o CVE_CAT.")
            return

        try:
            # Guardar estado para restauración
            for capa in [predios, manzanas, ejes]:
                estado_original[capa.id()] = {
                    'renderer': capa.renderer().clone(),
                    'labeling': capa.labeling().clone() if capa.labeling() else None,
                    'labelsEnabled': capa.labelsEnabled(),
                    'subsetString': capa.subsetString()
                }

            # ============================================
            # === FILTROS UI CORREGIDOS ===
            # ============================================
            filters = {}
            
            campo_usuario = encontrar_campo(predios, ["REALIZO", "MODIFICO", "USUARIO"])
            if campo_usuario:
                valores = sorted([str(v).strip() for v in predios.uniqueValues(predios.fields().indexOf(campo_usuario)) 
                               if v is not None and str(v).strip() != "" and str(v).upper() != "NULL"])
                if valores:
                    sel, ok = QInputDialog.getItem(None, "Filtro Personal", f"Seleccione {campo_usuario}:", ["(Todos)"] + valores, 0, False)
                    if ok and sel != "(Todos)" and sel.strip() != "": 
                        filters[campo_usuario] = sel
            
            campo_estatus = encontrar_campo(predios, ["ESTATUS", "STATUS"])
            if campo_estatus:
                valores = sorted([str(v).strip() for v in predios.uniqueValues(predios.fields().indexOf(campo_estatus)) 
                               if v is not None and str(v).strip() != "" and str(v).upper() != "NULL"])
                if valores:
                    sel, ok = QInputDialog.getItem(None, "Filtro Estatus", f"Seleccione {campo_estatus}:", ["(Todos)"] + valores, 0, False)
                    if ok and sel != "(Todos)" and sel.strip() != "": 
                        filters[campo_estatus] = sel

            # Diccionario ampliado para ser tolerante a diferentes nombres de columnas
            manuales = {
                "Municipio": ["MUNICIPIO", "CVE_MUN"], 
                "Zona": ["ZONA", "CVE_ZON", "CVE_ZONA"], 
                "Manzana": ["MANZANA", "CVE_MAN", "CLAVE_MANZANA"], 
                "Predio": ["PREDIO", "CVE_PRE", "LOTE"]
            }
            
            for f_lbl, f_candidates in manuales.items():
                c_found = encontrar_campo(predios, f_candidates)
                if c_found:
                    val, ok = QInputDialog.getText(None, f"Filtro: {f_lbl}", f"Ingrese {f_lbl}\n(Dejar en blanco para TODOS):")
                    if ok:
                        val_limpio = val.strip()
                        if val_limpio == "":
                            continue
                        # AQUI ESTABA EL ERROR: Se eliminó el "int()" que borraba los ceros a la izquierda.
                        filters[c_found] = val_limpio

            # Construcción de la condición SQL 
            condiciones = []
            for k, v in filters.items():
                idx = predios.fields().indexOf(k)
                if idx != -1 and predios.fields().at(idx).isNumeric():
                    # Validar que si es numérico, solo mandemos números limpios a la consulta SQL
                    if v.isdigit():
                        condiciones.append(f'"{k}" = {v}')
                    else:
                        condiciones.append(f'"{k}" = \'{v}\'')
                else:
                    condiciones.append(f'"{k}" = \'{v}\'')
            
            filter_expr = " AND ".join(condiciones)
            predios.setSubsetString(filter_expr)
            # ============================================

            estilo_manzana_numero(manzanas)
            estilo_predio_negro_solido(predios)
            os.makedirs(self.OUTPUT_FOLDER, exist_ok=True)
            
            feats_predios = list(predios.getFeatures())
            if not feats_predios: raise Exception("No se encontraron predios con los filtros seleccionados.")
            
            index_manzanas = QgsSpatialIndex(manzanas.getFeatures())
            index_ejes = QgsSpatialIndex(ejes.getFeatures())
            campo_manzana_link = encontrar_campo(manzanas, ["CVE_MAN", "CLAVE_MANZANA", "MANZANA"])
            campo_calle_ejes = encontrar_campo(ejes, ["CALLE", "NOMBRE", "VIALIDAD"])

            # VENTANA DE PROGRESO
            total = len(feats_predios)
            progress = QProgressDialog(f"Iniciando... (0 de {total})", "Cancelar Proceso", 0, total, self.iface.mainWindow())
            progress.setWindowTitle("Generando Croquis")
            progress.setWindowModality(Qt.WindowModal)
            progress.show()

            total_generados = 0

            # === BUCLE PRINCIPAL ===
            for idx, f_predio in enumerate(feats_predios):
                if progress.wasCanceled(): break
                progress.setValue(idx)
                
                layout = temp_layer = None
                clave = str(f_predio[campo_clave]) if f_predio[campo_clave] else f"Predio_{idx}"
                progress.setLabelText(f"Procesando predio {idx+1} de {total}\nClave: {clave}")
                QApplication.processEvents()
                    
                try:
                    geom_predio = f_predio.geometry()
                    if not geom_predio.isGeosValid(): geom_predio = geom_predio.makeValid()

                    ids = index_manzanas.intersects(geom_predio.boundingBox())
                    manzana_found = None
                    for mid in ids:
                        f_m = manzanas.getFeature(mid)
                        if f_m.geometry().intersects(geom_predio.pointOnSurface()):
                            manzana_found = f_m; break
                    
                    if not manzana_found: continue

                    # Aquí es donde fallaba si la columna no existía.
                    predios.setSubsetString(f"\"{campo_clave}\" = '{clave}'")
                    
                    if campo_manzana_link and manzana_found[campo_manzana_link]:
                        manzanas.setSubsetString(f"\"{campo_manzana_link}\" = '{manzana_found[campo_manzana_link]}'")
                    else:
                        manzanas.setSubsetString(f"$id = {manzana_found.id()}")

                    geom_manzana = manzana_found.geometry()
                    pt_centro_manzana = geom_manzana.centroid().asPoint()

                    # MOTOR DE RECORTE ORIGINAL
                    geom_recuadro = geom_manzana.buffer(self.DISTANCIA_RECUADRO, 5)
                    feats_temporales = []
                    calles_procesadas = []

                    candidatos_ejes = index_ejes.intersects(geom_recuadro.boundingBox())
                    for cid in candidatos_ejes:
                        f_eje = ejes.getFeature(cid)
                        nom = f_eje[campo_calle_ejes] if campo_calle_ejes else "Calle"
                        if not nom: continue
                        g_eje = f_eje.geometry()
                        if g_eje.intersects(geom_recuadro):
                            g_cortada = g_eje.intersection(geom_recuadro)
                            if not g_cortada.isEmpty() and g_cortada.length() > 2.0:
                                ft = QgsFeature()
                                ft.setGeometry(g_cortada)
                                ft.setAttributes([nom, "CALLE"])
                                feats_temporales.append(ft)
                                calles_procesadas.append(g_cortada)

                    contorno_manzana = geom_manzana.convertToType(QgsWkbTypes.LineGeometry)
                    if contorno_manzana.isMultipart():
                        col = contorno_manzana.asGeometryCollection()
                        if col: contorno_manzana = max(col, key=lambda g: g.length())
                    pts_contorno = contorno_manzana.asPolyline()
                    
                    for i in range(len(pts_contorno) - 1):
                        seg = QgsGeometry.fromPolylineXY([pts_contorno[i], pts_contorno[i+1]])
                        if seg.length() < self.LONGITUD_MINIMA_CARA: continue
                        ang_seg = calcular_angulo(seg)
                        area_chequeo = seg.buffer(10.0, 3)
                        tiene_calle_cerca = False
                        for g_calle in calles_procesadas:
                            if g_calle.intersects(area_chequeo):
                                inter = g_calle.intersection(area_chequeo)
                                if not inter.isEmpty() and inter.length() > 2.0:
                                    if son_paralelas(ang_seg, calcular_angulo(inter), 35):
                                        tiene_calle_cerca = True; break
                        if not tiene_calle_cerca:
                            geom_limite = desplazar_hacia_afuera(seg, pt_centro_manzana, self.DISTANCIA_LIMITE_FISICO)
                            ft_limite = QgsFeature()
                            ft_limite.setGeometry(geom_limite)
                            ft_limite.setAttributes(["LIMITE FISICO", "LIMITE"])
                            feats_temporales.append(ft_limite)

                    if feats_temporales:
                        temp_layer = QgsVectorLayer(f"LineString?crs={ejes.crs().authid()}", "Etiquetas", "memory")
                        pr = temp_layer.dataProvider()
                        pr.addAttributes([QgsField("NOMBRE", QVariant.String), QgsField("TIPO", QVariant.String)])
                        temp_layer.updateFields()
                        pr.addFeatures(feats_temporales)
                        QgsProject.instance().addMapLayer(temp_layer, False)
                        estilo_capa_temporal(temp_layer, self.TAMANO_TEXTO_CALLES, self.TAMANO_TEXTO_LIMITES)
                        capas_mapa = [temp_layer, manzanas, predios]
                    else:
                        capas_mapa = [manzanas, predios]

                    # LAYOUT Y CENTRADO PERFECTO
                    layout = QgsPrintLayout(QgsProject.instance())
                    layout.initializeDefaults()
                    map_item = QgsLayoutItemMap(layout)
                    map_item.setFrameEnabled(False)
                    map_item.setLayers(capas_mapa)
                    map_item.attemptResize(QgsLayoutSize(300, 170, QgsUnitTypes.LayoutMillimeters))
                    map_item.attemptMove(QgsLayoutPoint(0, 0, QgsUnitTypes.LayoutMillimeters))
                    
                    # Lógica de centrado proporcional
                    bbox_base = geom_recuadro.boundingBox()
                    centro_mapa = bbox_base.center()
                    target_ratio = 300.0 / 170.0
                    w, h = bbox_base.width(), bbox_base.height()
                    if (w / h) > target_ratio:
                        nueva_w = w * 1.1 # Margen 10%
                        nueva_h = nueva_w / target_ratio
                    else:
                        nueva_h = h * 1.1
                        nueva_w = nueva_h * target_ratio

                    rect_final = QgsRectangle(
                        centro_mapa.x() - nueva_w/2, centro_mapa.y() - nueva_h/2,
                        centro_mapa.x() + nueva_w/2, centro_mapa.y() + nueva_h/2
                    )
                    map_item.setExtent(rect_final)
                    layout.addLayoutItem(map_item)

                    # ========================================================
                    # PARCHE DE ESTABILIDAD: REFRESCAR ANTES DE EXPORTAR
                    # ========================================================
                    map_item.refresh()
                    QApplication.processEvents()

                    exporter = QgsLayoutExporter(layout)
                    ruta_salida = os.path.join(self.OUTPUT_FOLDER, f"{clave}.jpg")
                    img_settings = QgsLayoutExporter.ImageExportSettings()
                    img_settings.dpi = 300
                    exporter.exportToImage(ruta_salida, img_settings)
                    total_generados += 1

                except Exception as e_inner:
                    print(f"Error en {clave}: {e_inner}")
                finally:
                    if temp_layer: QgsProject.instance().removeMapLayer(temp_layer.id())
                    if layout: QgsProject.instance().layoutManager().removeLayout(layout)
                    predios.setSubsetString(filter_expr)
                    manzanas.setSubsetString("")

            progress.setValue(total)
            QMessageBox.information(None, "Terminado", f"Proceso finalizado.\nCroquis generados: {total_generados}")

        except Exception as e:
            QMessageBox.critical(None, "Error", str(e))
        finally:
            for c_id, st in estado_original.items():
                capa = QgsProject.instance().mapLayer(c_id)
                if capa:
                    capa.setRenderer(st['renderer'])
                    if st['labeling']: capa.setLabeling(st['labeling'])
                    capa.setLabelsEnabled(st['labelsEnabled'])
                    capa.setSubsetString(st['subsetString'])
                    capa.triggerRepaint()
            gc.collect()