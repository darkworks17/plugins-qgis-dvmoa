def classFactory(iface):
    from .croquis_plugin import CroquisDVMOAPlugin
    return CroquisDVMOAPlugin(iface)
