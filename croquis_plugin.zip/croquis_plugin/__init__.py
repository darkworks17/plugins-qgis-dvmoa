def classFactory(iface):
    from .croquis_plugin import CroquisUbicacionPlugin
    return CroquisUbicacionPlugin(iface)
