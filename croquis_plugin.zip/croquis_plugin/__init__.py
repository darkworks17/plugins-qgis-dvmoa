def classFactory(iface):
    from .croquis_plugin import CroquisManzanaPlugin
    return CroquisManzanaPlugin(iface)
