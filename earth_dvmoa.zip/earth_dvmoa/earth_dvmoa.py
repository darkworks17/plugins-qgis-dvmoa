# -*- coding: utf-8 -*-
import os
import sys
import tempfile
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
# Se agregó QMenu a la importación
from qgis.PyQt.QtWidgets import QAction, QToolBar, QMenu 
from qgis.gui import QgsMapToolEmitPoint
from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject
from qgis.utils import iface

# 1. HERRAMIENTA DE MAPA (Carga de Icono Personalizado para el Puntero)
class HerramientaEarth(QgsMapToolEmitPoint):
    def __init__(self, canvas, iface_instance, plugin_dir):
        self.canvas = canvas
        self.iface = iface_instance
        self.plugin_dir = plugin_dir
        QgsMapToolEmitPoint.__init__(self, self.canvas)
        
        # Archivo temporal para el vuelo
        self.kml_path = os.path.join(tempfile.gettempdir(), 'dvmoa_vuelo.kml')

    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        crs_src = self.canvas.mapSettings().destinationCrs()
        crs_dest = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(crs_src, crs_dest, QgsProject.instance())
        
        try:
            pt_wgs84 = transform.transform(point)
            lon, lat = pt_wgs84.x(), pt_wgs84.y()
            
            # Ruta al icono del puntero (convertida para Google Earth)
            icon_file = os.path.join(self.plugin_dir, 'punterodvmoa.png')
            # Google Earth prefiere rutas con barras hacia adelante /
            icon_url = icon_file.replace('\\', '/')
            
            # KML que usa tu imagen personalizada
            kml_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <Style id="customPointer">
      <IconStyle>
        <scale>1.5</scale>
        <Icon>
          <href>file:///{icon_url}</href>
        </Icon>
      </IconStyle>
      <LabelStyle>
        <scale>0</scale>
      </LabelStyle>
    </Style>
    <Placemark>
      <styleUrl>#customPointer</styleUrl>
      <LookAt>
        <longitude>{lon}</longitude>
        <latitude>{lat}</latitude>
        <altitude>0</altitude>
        <range>450</range>
        <tilt>0</tilt>
        <heading>0</heading>
        <altitudeMode>relativeToGround</altitudeMode>
      </LookAt>
      <Point>
        <coordinates>{lon},{lat},0</coordinates>
      </Point>
    </Placemark>
  </Document>
</kml>"""

            with open(self.kml_path, 'w', encoding='utf-8') as f:
                f.write(kml_content)
            
            if os.name == 'nt':
                os.startfile(self.kml_path)
            else:
                import subprocess
                opener = 'open' if sys.platform == 'darwin' else 'xdg-open'
                subprocess.call((opener, self.kml_path))
                
        except Exception as e:
            self.iface.messageBar().pushMessage("Error", str(e), level=2)

# 2. CLASE DEL PLUGIN
class EarthPluginDVMOA:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.earth_tool = None
        self.action = None
        self.toolbar = None
        self.dvmoa_menu = None # Variable para gestionar el menú superior

    def initGui(self):
        # Icono de la barra de herramientas de QGIS
        icon_path = os.path.join(self.plugin_dir, 'earth_dvmoa.png')
        
        self.action = QAction(QIcon(icon_path), "Earth DVMOA", self.iface.mainWindow())
        self.action.triggered.connect(self.activar_herramienta)
        
        # --- LÓGICA DE MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        # Revisamos si el menú "&DVMOA" ya fue creado por otra de tus herramientas
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si no existe, lo creamos
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        # Agregamos nuestra acción a este menú principal
        self.dvmoa_menu.addAction(self.action)
        
        # Mantengo intacta la lógica de tu barra de herramientas
        self.toolbar = self.iface.addToolBar("DVMOA Tools")
        self.toolbar.setObjectName("DVMOATools")
        self.toolbar.addAction(self.action)

    def unload(self):
        # Removemos la acción del menú principal
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            # Si el menú se queda sin botones, lo eliminamos
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
                
        if self.toolbar:
            self.iface.mainWindow().removeToolBar(self.toolbar)
            
        canvas = self.iface.mapCanvas()
        if self.earth_tool and canvas.mapTool() == self.earth_tool:
            canvas.unsetMapTool(self.earth_tool)

    def activar_herramienta(self):
        canvas = self.iface.mapCanvas()
        if self.earth_tool is None:
            # Pasamos la ruta del plugin a la herramienta para que encuentre el puntero
            self.earth_tool = HerramientaEarth(canvas, self.iface, self.plugin_dir)
        
        canvas.setMapTool(self.earth_tool)
        self.iface.messageBar().pushMessage("Earth DVMOA", "Usando puntero personalizado.", level=0, duration=2)