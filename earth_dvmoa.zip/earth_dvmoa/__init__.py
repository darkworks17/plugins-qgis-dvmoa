def classFactory(iface):
    from .earth_dvmoa import EarthPluginDVMOA
    return EarthPluginDVMOA(iface)
