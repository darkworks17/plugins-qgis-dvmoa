import os
import csv
import math
import processing
from datetime import datetime

from qgis.PyQt.QtWidgets import QAction, QInputDialog, QMessageBox, QFileDialog
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsProject, 
    QgsVectorFileWriter
)

class RespaldoDvmoa:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None

    def initGui(self):
        # Nombre exacto de tu icono
        icon_path = os.path.join(self.plugin_dir, 'respaldo_dvmoa.png')
        
        self.action = QAction(QIcon(icon_path), "Generar Respaldo (Cortes)", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # 1. Se añade a tu menú DVMOA
        self.iface.addPluginToMenu("DVMOA", self.action)
        # 2. Se añade a la barra de herramientas
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("DVMOA", self.action)
        self.iface.removeToolBarIcon(self.action)
        del self.action

    # ============================================
    # FUNCIONES AUXILIARES
    # ============================================
    def valor_valido(self, valor):
        if valor is None:
            return False
        v = str(valor).strip().lower()
        if v in ["", "nan", "none", "null"]:
            return False
        return True

    def crear_in(self, campo, valores):
        if not valores:
            return None
        lista = []
        for v in valores:
            v_str = str(v).strip()
            if not self.valor_valido(v_str):
                continue
            v_str = v_str.replace("'", "''")
            
            es_num = False
            try:
                float(v_str)
                es_num = True
            except ValueError:
                pass
                
            if es_num:
                lista.append(v_str)
            else:
                lista.append(f"'{v_str}'")
                
        if not lista:
            return None
        return f'"{campo}" IN ({",".join(lista)})'

    def guardar(self, capa, ruta):
        # Actualizado a writeAsVectorFormatV2 (la forma correcta en QGIS 3)
        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.driverName = "ESRI Shapefile"
        save_options.fileEncoding = "UTF-8"
        QgsVectorFileWriter.writeAsVectorFormatV2(capa, ruta, QgsProject.instance().transformContext(), save_options)

    # ============================================
    # PROCESO PRINCIPAL
    # ============================================
    def run(self):
        # --- 0. PREGUNTAR NOMBRE DEL RESPALDO ---
        nombre_respaldo, ok_nombre = QInputDialog.getText(
            self.iface.mainWindow(),
            "Nombre del Respaldo",
            "Ingresa el nombre para la carpeta de este respaldo\n(Ej. Proyecto_Centro, Zona_Norte):"
        )
        
        if not ok_nombre or not nombre_respaldo.strip():
            return # Se canceló la operación

        nombre_respaldo = nombre_respaldo.strip()

        # --- 1. SELECCIONAR MODO DE FILTRO ---
        modo, ok_modo = QInputDialog.getItem(
            self.iface.mainWindow(),
            "Modo de filtro",
            "Selecciona cómo quieres filtrar los predios:",
            ["Manual", "Archivo (CSV / Excel)"],
            0,
            False
        )

        if not ok_modo:
            return

        # --- 2. CARGAR CAPA PREDIOS ---
        predios_list = QgsProject.instance().mapLayersByName("Predios")
        if not predios_list:
            QMessageBox.critical(self.iface.mainWindow(), "Error", "❌ No existe la capa 'Predios' en el proyecto.")
            return

        predios = predios_list[0]
        field_names = [f.name().upper() for f in predios.fields()]

        campos = ["REALIZO", "ESTATUS", "MUNICIPIO", "ZONA", "MANZANA", "PREDIO"]
        filtros_raw = {}

        def agregar_valor(campo, valor):
            if not self.valor_valido(valor):
                return
            v = str(valor).strip()
            if campo not in filtros_raw:
                filtros_raw[campo] = set()
            filtros_raw[campo].add(v)

        # --- 3. CAPTURAR FILTROS ---
        if modo == "Manual":
            for campo in campos:
                if campo not in field_names:
                    continue
                texto, ok_txt = QInputDialog.getText(
                    self.iface.mainWindow(),
                    f"Filtro {campo}",
                    f"Ingrese valores separados por coma para {campo}\nEjemplo: 001,002,003\n(Dejar vacío = sin filtro)"
                )
                if ok_txt and texto.strip():
                    for v in texto.split(","):
                        agregar_valor(campo, v)
        else:
            ruta_archivo, _ = QFileDialog.getOpenFileName(
                self.iface.mainWindow(),
                "Seleccionar archivo",
                "",
                "CSV (*.csv);;Excel (*.xlsx *.xls)"
            )
            if not ruta_archivo:
                return

            if ruta_archivo.lower().endswith(".csv"):
                with open(ruta_archivo, newline='', encoding='utf-8-sig') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        for campo, valor in row.items():
                            if campo:
                                agregar_valor(campo.strip().upper(), valor)
            else:
                import pandas as pd
                df = pd.read_excel(ruta_archivo)
                df.columns = df.columns.str.strip()
                for _, row in df.iterrows():
                    for campo in df.columns:
                        valor = row[campo]
                        if isinstance(valor, float) and math.isnan(valor):
                            continue
                        agregar_valor(str(campo).strip().upper(), valor)

        # Convertir sets a listas
        filtros = {k: list(v) for k, v in filtros_raw.items() if v}

        # --- 4. CREAR EXPRESIÓN SQL ---
        expresiones = []
        for campo, valores in filtros.items():
            if campo in field_names:
                exp = self.crear_in(campo, valores)
                if exp:
                    expresiones.append(exp)

        expresion_final = " AND ".join(expresiones)
        self.iface.messageBar().pushMessage("Generando", "Filtrando y extrayendo capas...", level=0, duration=4)

        # --- 5. FILTRAR PREDIOS ---
        if expresion_final:
            predios_filtrados = processing.run(
                "native:extractbyexpression",
                {
                    'INPUT': predios,
                    'EXPRESSION': expresion_final,
                    'OUTPUT': 'memory:'
                }
            )['OUTPUT']
        else:
            predios_filtrados = predios

        if predios_filtrados.featureCount() == 0:
            QMessageBox.warning(self.iface.mainWindow(), "Sin resultados", "⚠️ La consulta no arrojó ningún predio.")
            return

        # --- 6. CREAR CARPETA C:\DVMOA\RESPALDO_DVMOA ---
        ruta_base = r"C:\DVMOA\RESPALDO_DVMOA"
        carpeta_salida = os.path.join(ruta_base, nombre_respaldo)
        
        # Crea las carpetas si no existen
        os.makedirs(carpeta_salida, exist_ok=True)

        # --- 7. GUARDAR CAPA PREDIOS ---
        self.guardar(predios_filtrados, os.path.join(carpeta_salida, "Predios.shp"))

        # --- 8. INTERSECCIÓN DE DEMÁS CAPAS ---
        capas_nombres = [
            "Manzanas","Bardas","Frente_Predios","Fondo_Predios",
            "Const_N1","Const_N2","Const_N3","Const_N4","Const_N5",
            "Const_N6","Const_N7","Const_N8","Const_N9","Const_N10"
        ]

        for nombre_capa in capas_nombres:
            capas_en_qgis = QgsProject.instance().mapLayersByName(nombre_capa)
            if not capas_en_qgis:
                continue # Si no existe la capa, simplemente la salta
            
            capa_a_cruzar = capas_en_qgis[0]
            
            res = processing.run(
                "native:extractbylocation",
                {
                    'INPUT': capa_a_cruzar,
                    'PREDICATE': [0], # intersects
                    'INTERSECT': predios_filtrados,
                    'OUTPUT': 'memory:'
                }
            )['OUTPUT']

            if res.featureCount() > 0:
                self.guardar(res, os.path.join(carpeta_salida, f"{nombre_capa}.shp"))

        # --- 9. FINALIZAR ---
        QMessageBox.information(
            self.iface.mainWindow(), 
            "¡Éxito!", 
            f"Cortes generados correctamente.\n\nUbicación:\n{carpeta_salida}"
        )