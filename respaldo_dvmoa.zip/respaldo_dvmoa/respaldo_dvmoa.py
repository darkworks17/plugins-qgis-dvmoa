import os
import csv
import processing

from qgis.PyQt.QtWidgets import (QAction, QInputDialog, QMessageBox, 
                                 QFileDialog, QProgressDialog)
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt
from qgis.core import (
    QgsProject, 
    QgsVectorFileWriter,
    QgsApplication
)

class RespaldoDvmoa:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dvmoa_menu = None # Variable para guardar la referencia del menú principal

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'respaldo_dvmoa.png')
        self.action = QAction(QIcon(icon_path), "Generar Respaldo (Cortes)", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # 1. Obtenemos la barra de menús principal de QGIS
        menu_bar = self.iface.mainWindow().menuBar()

        # 2. Buscamos tu menú principal llamado "DVMOA"
        for m_action in menu_bar.actions():
            menu = m_action.menu()
            # Usamos replace por si el título tiene un '&' (atajos de teclado)
            if menu and menu.title().replace('&', '') == "DVMOA":
                self.dvmoa_menu = menu
                break

        # 3. Si encuentra tu menú principal, agrega la acción ahí.
        if self.dvmoa_menu:
            self.dvmoa_menu.addAction(self.action)
        else:
            # Si por alguna razón no lo encuentra, usa el método por defecto (Complementos)
            self.iface.addPluginToMenu("DVMOA", self.action)
            
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Dependiendo de dónde se haya inyectado, lo removemos al descargar el plugin
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
        else:
            self.iface.removePluginMenu("DVMOA", self.action)
            
        self.iface.removeToolBarIcon(self.action)
        del self.action

    # ============================================
    # FUNCIONES AUXILIARES
    # ============================================
    def valor_valido(self, valor):
        if valor is None:
            return False
        v = str(valor).strip().lower()
        if v in ["", "nan", "none", "null"]:
            return False
        return True

    def crear_in(self, campo, valores):
        if not valores:
            return None
        lista = []
        for v in valores:
            v_str = str(v).strip()
            if not self.valor_valido(v_str):
                continue
            v_str = v_str.replace("'", "''")
            
            es_num = False
            try:
                float(v_str)
                es_num = True
            except ValueError:
                pass
                
            if es_num:
                lista.append(v_str)
            else:
                lista.append(f"'{v_str}'")
                
        if not lista:
            return None
        return f'"{campo}" IN ({",".join(lista)})'

    def guardar(self, capa, ruta):
        try:
            save_options = QgsVectorFileWriter.SaveVectorOptions()
            save_options.driverName = "ESRI Shapefile"
            save_options.fileEncoding = "UTF-8"
            
            error_code, error_msg = QgsVectorFileWriter.writeAsVectorFormatV2(
                capa, ruta, QgsProject.instance().transformContext(), save_options
            )
            
            if error_code != QgsVectorFileWriter.NoError:
                QMessageBox.warning(self.iface.mainWindow(), "Error al guardar", 
                                    f"No se pudo guardar la capa en:\n{ruta}\n\nError: {error_msg}")
        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "Error Inesperado", f"Ocurrió un error al guardar:\n{str(e)}")

    # ============================================
    # PROCESO PRINCIPAL
    # ============================================
    def run(self):
        # --- 0. PREGUNTAR NOMBRE DEL RESPALDO ---
        nombre_respaldo, ok_nombre = QInputDialog.getText(
            self.iface.mainWindow(),
            "Nombre del Respaldo",
            "Ingresa un nombre para la carpeta de este corte (Ej. Proyecto_Mes_2026):"
        )
        
        if not ok_nombre or not nombre_respaldo.strip():
            return # Se canceló la operación
            
        # --- 1. CREAR RUTA BASE AUTOMÁTICA ---
        ruta_base = r"C:\DVMOA\RESPALDO_DVMOA"
        carpeta_salida = os.path.join(ruta_base, nombre_respaldo.strip())

        # --- 2. SELECCIONAR MODO DE FILTRO ---
        modo, ok_modo = QInputDialog.getItem(
            self.iface.mainWindow(),
            "Modo de filtro",
            "Selecciona cómo quieres filtrar los predios:",
            ["Manual", "Archivo (CSV)"],
            0,
            False
        )

        if not ok_modo:
            return

        # --- 3. CARGAR CAPA PREDIOS ---
        predios_list = QgsProject.instance().mapLayersByName("Predios")
        if not predios_list:
            QMessageBox.critical(self.iface.mainWindow(), "Error", "❌ No existe la capa 'Predios' en el proyecto.")
            return

        predios = predios_list[0]
        field_names = [f.name().upper() for f in predios.fields()]

        campos = ["REALIZO", "ESTATUS", "MUNICIPIO", "ZONA", "MANZANA", "PREDIO"]
        filtros_raw = {}

        def agregar_valor(campo, valor):
            if not self.valor_valido(valor):
                return
            v = str(valor).strip()
            if campo not in filtros_raw:
                filtros_raw[campo] = set()
            filtros_raw[campo].add(v)

        # --- 4. CAPTURAR FILTROS ---
        if modo == "Manual":
            for campo in campos:
                if campo not in field_names:
                    continue
                texto, ok_txt = QInputDialog.getText(
                    self.iface.mainWindow(),
                    f"Filtro {campo}",
                    f"Ingrese valores separados por coma para {campo}\nEjemplo: 001,002,003\n(Dejar vacío = sin filtro)"
                )
                if ok_txt and texto.strip():
                    for v in texto.split(","):
                        agregar_valor(campo, v)
        else:
            ruta_archivo, _ = QFileDialog.getOpenFileName(
                self.iface.mainWindow(),
                "Seleccionar archivo CSV",
                "",
                "CSV (*.csv)"
            )
            if not ruta_archivo:
                return

            try:
                with open(ruta_archivo, newline='', encoding='utf-8-sig') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        for campo, valor in row.items():
                            if campo:
                                agregar_valor(campo.strip().upper(), valor)
            except Exception as e:
                QMessageBox.critical(self.iface.mainWindow(), "Error", f"No se pudo leer el archivo CSV:\n{e}")
                return

        # Convertir sets a listas
        filtros = {k: list(v) for k, v in filtros_raw.items() if v}

        # --- 5. CREAR EXPRESIÓN SQL ---
        expresiones = []
        for campo, valores in filtros.items():
            if campo in field_names:
                exp = self.crear_in(campo, valores)
                if exp:
                    expresiones.append(exp)

        expresion_final = " AND ".join(expresiones)
        self.iface.messageBar().pushMessage("Generando", "Filtrando Predios...", level=0, duration=2)

        # --- 6. FILTRAR PREDIOS ---
        if expresion_final:
            predios_filtrados = processing.run(
                "native:extractbyexpression",
                {
                    'INPUT': predios,
                    'EXPRESSION': expresion_final,
                    'OUTPUT': 'memory:'
                }
            )['OUTPUT']
        else:
            predios_filtrados = predios

        if predios_filtrados.featureCount() == 0:
            QMessageBox.warning(self.iface.mainWindow(), "Sin resultados", "⚠️ La consulta no arrojó ningún predio.")
            return

        # --- 7. CREAR CARPETA DE SALIDA ---
        os.makedirs(carpeta_salida, exist_ok=True)

        # --- 8. GUARDAR CAPA PREDIOS ---
        self.guardar(predios_filtrados, os.path.join(carpeta_salida, "Predios.shp"))

        # --- 9. INTERSECCIÓN DE CAPAS CON BARRA DE PROGRESO ---
        capas_nombres = [
            "Manzanas","Bardas","Frente_Predios","Fondo_Predios",
            "Const_N1","Const_N2","Const_N3","Const_N4","Const_N5",
            "Const_N6","Const_N7","Const_N8","Const_N9","Const_N10"
        ]
        
        capas_validas = [n for n in capas_nombres if QgsProject.instance().mapLayersByName(n)]
        
        if capas_validas:
            progreso = QProgressDialog("Iniciando cortes espaciales...", "Cancelar", 0, len(capas_validas), self.iface.mainWindow())
            progreso.setWindowTitle("Generando Respaldo DVMOA")
            progreso.setWindowModality(Qt.WindowModal)
            progreso.show()

            for i, nombre_capa in enumerate(capas_validas):
                if progreso.wasCanceled():
                    QMessageBox.warning(self.iface.mainWindow(), "Cancelado", "El proceso fue cancelado por el usuario.")
                    break
                    
                progreso.setLabelText(f"Cortando capa: {nombre_capa} ({i+1}/{len(capas_validas)})")
                progreso.setValue(i)
                QgsApplication.processEvents() # Mantiene QGIS vivo y evita el "No responde"

                capa_a_cruzar = QgsProject.instance().mapLayersByName(nombre_capa)[0]
                ruta_salida_directa = os.path.join(carpeta_salida, f"{nombre_capa}.shp")
                
                try:
                    # Guardar directo
                    processing.run(
                        "native:extractbylocation",
                        {
                            'INPUT': capa_a_cruzar,
                            'PREDICATE': [0], # intersects
                            'INTERSECT': predios_filtrados,
                            'OUTPUT': ruta_salida_directa
                        }
                    )
                except Exception as e:
                    self.iface.messageBar().pushMessage("Error", f"Fallo al cortar {nombre_capa}: {e}", level=2, duration=5)

            progreso.setValue(len(capas_validas))

        # --- 10. FINALIZAR ---
        QMessageBox.information(
            self.iface.mainWindow(), 
            "¡Éxito!", 
            f"Cortes generados correctamente.\n\nUbicación:\n{carpeta_salida}"
        )