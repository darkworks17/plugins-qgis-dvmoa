import os
import processing
from PyQt5.QtCore import QVariant, Qt
from PyQt5.QtGui import QColor, QIcon
from PyQt5.QtWidgets import QAction, QMenu, QMessageBox
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsVectorFileWriter,
    QgsField, QgsFields, QgsFeature,
    QgsFillSymbol, QgsLineSymbol, QgsSingleSymbolRenderer
)
from qgis.utils import iface

# ============================================
# FUNCIONES AUXILIARES
# ============================================
def obtener_estilo_linea(tipo):
    if tipo.lower() == "puntos":
        return "Dash"
    elif tipo.lower() == "puntos_reales":
        return "Dot"
    return "Solid"

# ============================================
# CLASE PRINCIPAL DEL PLUGIN
# ============================================
class ExportarIGECEMPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dvmoa_menu = None # Variable para gestionar el menú superior

    def initGui(self):
        # ---> AQUÍ SE CORRIGIÓ EL NOMBRE DEL ICONO <---
        icon_path = os.path.join(self.plugin_dir, 'respaldo_dvmoa.png')
        
        # ---> AQUÍ SE CAMBIÓ EL NOMBRE A MOSTRAR EN EL MENÚ Y TOOLTIP <---
        self.action = QAction(QIcon(icon_path), "Respaldo_DVMOA", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # --- LÓGICA DE MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        # Revisamos si el menú "&DVMOA" ya fue creado por otra de tus herramientas
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si no existe, lo creamos
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        # Agregamos nuestra acción a este menú principal
        self.dvmoa_menu.addAction(self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Removemos la acción del menú principal creado
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            # Si el menú se queda sin botones, lo eliminamos
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
                
        self.iface.removeToolBarIcon(self.action)
        del self.action

    def run(self):
        self.iface.messageBar().pushMessage("Iniciando", "Iniciando exportación de capas...", level=0, duration=3)
        
        # ---------------- CONFIGURACIÓN GENERAL ---------------- #
        # Carpeta de salida
        output_folder = r"C:\DVMOA\IGECEM\SHP"
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # Diccionario de capas y campos
        capas_config = {
            "Predios": [
                ("MUNICIPIO", "MUN", QVariant.Int, 3),
                ("ZONA", "ZON", QVariant.Int, 2),
                ("MANZANA", "MAN", QVariant.Int, 3),
                ("PREDIO", "PRE", QVariant.Int, 2),
                ("CLAVECATAS", "CVE_PRE", QVariant.String, 10)
            ],
            "Municipio": [
                ("municipio", "MUN", QVariant.Int, 3),
                ("nom_mun", "nom_mun", QVariant.String, 30)
            ],
            "Manzanas": [
                ("MUNICIPIO", "MUN", QVariant.Int, 3),
                ("ZONA", "ZON", QVariant.Int, 2),
                ("MANZANA", "MAN", QVariant.Int, 3),
                ("CVE_MAN", "CVE_MAN", QVariant.String, 8)
            ],
            "Estado": [
                ("cve_ent", "cve_ent", QVariant.String, 2),
                ("nom_ent", "nom_ent", QVariant.String, 16)
            ],
            "Area_Homogenea": [
                ("MUN", "MUN", QVariant.Int, 3),
                ("ARE", "ARE", QVariant.String, 3),
                ("tipo", "tipo", QVariant.String, 2)
            ],
            "Const_*": [
                ("CLAVECATAS", "CVE_DEP", QVariant.String, 16),
                ("ID_CONSTR", "unidad", QVariant.Int, 3),
                ("CVECLASIF", "tipologi", QVariant.String, 3)
            ],
            "Bardas": [
                ("CLAVECATAS", "CVE_DEP", QVariant.String, 16),
                ("ID_CONSTR", "unidad", QVariant.Int, 3),
                ("CVECLASIF", "tipologi", QVariant.String, 3)
            ],
            "Marquesina": [
                ("CLAVECATAS", "CVE_DEP", QVariant.String, 16),
                ("ID_CONSTR", "unidad", QVariant.Int, 3),
                ("CVECLASIF", "tipologi", QVariant.String, 3)
            ],
            "Voladizos": [
                ("CLAVECATAS", "CVE_DEP", QVariant.String, 16),
                ("ID_CONSTR", "unidad", QVariant.Int, 3),
                ("CVECLASIF", "tipologi", QVariant.String, 3)
            ],
            "Banda_Valor": [
                ("MUNICIPIO", "MUN", QVariant.Int, 3),
                ("BANDA", "num_b", QVariant.Int, 3),
                ("ZONAORIG", "zn_orig", QVariant.Int, 2),
                ("CODCALLE", "cod_call", QVariant.Int, 4),
                ("NOM_CALLE", "calle", QVariant.String, 50)
            ],
            "Frente_Predios": [
                ("CVE_PRE", "CVE_PRE", QVariant.String, 10),
                ("FRENTE", "FRENTE", QVariant.Double, 8)
            ],
            "Fondo_Predios": [
                ("CVE_PRE", "CVE_PRE", QVariant.String, 10),
                ("FONDO", "FONDO", QVariant.Double, 8)
            ]
        }

        # ---------------- EXPORTAR SHAPEFILES ---------------- #
        project = QgsProject.instance()
        capas_cargadas = {layer.name(): layer for layer in project.mapLayers().values()}

        print("\n===== EXPORTACIÓN DE CAPAS INICIADA =====\n")

        for capa_nombre, campos_conf in capas_config.items():
            # Manejar comodín para Const_N*
            capas_a_exportar = []
            if capa_nombre.endswith("*"):
                prefijo = capa_nombre[:-1]
                capas_a_exportar = [l for l in capas_cargadas if l.startswith(prefijo)]
            else:
                capas_a_exportar = [capa_nombre] if capa_nombre in capas_cargadas else []

            if not capas_a_exportar:
                print(f"⚠️  Capa '{capa_nombre}' no encontrada. Se omite.")
                continue

            for nombre_capa in capas_a_exportar:
                capa = capas_cargadas[nombre_capa]
                print(f"Procesando capa: {nombre_capa}")

                # Crear estructura de campos para la nueva capa
                fields = QgsFields()
                for original, nuevo, tipo, tam in campos_conf:
                    if tipo == QVariant.Double:
                        fields.append(QgsField(nuevo, tipo, len=8, prec=2))
                    else:
                        fields.append(QgsField(nuevo, tipo, len=tam))

                # Crear shapefile de salida
                salida = os.path.join(output_folder, f"{nombre_capa}.shp")
                writer = QgsVectorFileWriter(
                    salida,
                    "UTF-8",
                    fields,
                    capa.wkbType(),
                    capa.sourceCrs(),
                    "ESRI Shapefile"
                )

                # Copiar geometrías y atributos
                field_map = {f.name().lower(): f.name() for f in capa.fields()}
                for feat in capa.getFeatures():
                    new_feat = QgsFeature()
                    new_feat.setGeometry(feat.geometry())
                    attrs = []
                    for original, nuevo, tipo, tam in campos_conf:
                        campo_real = field_map.get(original.lower())
                        if campo_real and capa.fields().indexFromName(campo_real) >= 0:
                            valor = feat[campo_real]
                            # Recortar CLAVECATAS en Predios
                            if nombre_capa == "Predios" and original == "CLAVECATAS" and valor:
                                valor = str(valor)[:10]
                            attrs.append(valor)
                        else:
                            attrs.append(None)
                    new_feat.setAttributes(attrs)
                    writer.addFeature(new_feat)

                del writer
                print(f"✅ Capa exportada: {salida}")

        print("\n===== ✅ EXPORTACIÓN COMPLETA =====")

        # ---------------- CONFIGURACIÓN GPKG Y ESTILOS ----------------
        shp_folder = r"C:\DVMOA\IGECEM\SHP"
        gpkg_path = r"C:\DVMOA\IGECEM\Entrega_Cuautitlán Izcalli4(Febrero_20206).gpkg"

        # ---------------- LIMPIAR GPKG ANTERIOR ----------------
        if os.path.exists(gpkg_path):
            try:
                os.remove(gpkg_path)
                print(f"🗑 Archivo GPKG anterior eliminado: {gpkg_path}")
            except PermissionError:
                print(f"⚠ No se pudo eliminar el GPKG anterior, puede estar en uso: {gpkg_path}")

        # ---------------- ESTILOS ----------------
        estilos_capas = {
            "Estado": {"contorno": "#7f0000", "relleno": None, "ancho": 1.0, "tipo_linea": "sólida"},
            "Municipio": {"contorno": "#7f0000", "relleno": None, "ancho": 0.9, "tipo_linea": "puntos_reales"},  # especial
            "Zona": {"contorno": "#342c7a", "relleno": None, "ancho": 0.8, "tipo_linea": "sólida"},
            "Area_Homogenea": {"contorno": "#137171", "relleno": None, "ancho": 0.7, "tipo_linea": "sólida"},
            "Banda_Valor": {"contorno": "#9e5519", "relleno": None, "ancho": 0.6, "tipo_linea": "sólida"},
            "Manzanas": {"contorno": "#faf1df", "relleno": "#faf1df", "ancho": 0.2, "tipo_linea": "sólida"},
            "Eje_Calle": {"contorno": "#000000", "relleno": None, "ancho": 0.2, "tipo_linea": "sólida"},
            "Areas_Verdes": {"contorno": "#000000", "relleno": "#00CC00", "ancho": 0.2, "tipo_linea": "sólida"},
            "Camellon_otros": {"contorno": "#000000", "relleno": "#CC66FF", "ancho": 0.1, "tipo_linea": "sólida"},
            "Condominios": {"contorno": "#000000", "relleno": "#7e7e7e", "ancho": 0.3, "tipo_linea": "sólida"},
            "Predios": {"contorno": "#0084ff", "relleno": None, "ancho": 0.5, "tipo_linea": "sólida"},
            "Frente_Predios": {"contorno": "#33a02c", "relleno": None, "ancho": 1.2, "tipo_linea": "sólida"},
            "Fondo_Predios": {"contorno": "#91522d", "relleno": None, "ancho": 1.2, "tipo_linea": "sólida"},
            "Area_Ins_Predios": {"contorno": "#000000", "relleno": None, "ancho": 0.4, "tipo_linea": "sólida"},
            "Area_aprov": {"contorno": "#4901ff", "relleno": None, "ancho": 0.4, "tipo_linea": "sólida"},
            "Const_S1": {"contorno": "#e1f5ff", "relleno": "#e1f5ff", "ancho": 0.5, "tipo_linea": "sólida"},
            "Const_S2": {"contorno": "#e1f5ff", "relleno": "#e1f5ff", "ancho": 0.5, "tipo_linea": "sólida"},
            "Const_S3": {"contorno": "#e1f5ff", "relleno": "#e1f5ff", "ancho": 0.5, "tipo_linea": "sólida"},
            "Marquesina": {"contorno": "#9fb6c3", "relleno": "#eadbd3", "ancho": 0.5, "tipo_linea": "sólida"},
            "Voladizos": {"contorno": "#9fb6c3", "relleno": "#eadbd3", "ancho": 0.5, "tipo_linea": "sólida"},
            "Const_N1": {"contorno": "#9fb6c3", "relleno": "#eadbd3", "ancho": 0.5, "tipo_linea": "sólida"},
            "Const_N2": {"contorno": "#9fb6c3", "relleno": "#e3cbbf", "ancho": 0.5, "tipo_linea": "sólida"},
            "Const_N3": {"contorno": "#9fb6c3", "relleno": "#d4b5a5", "ancho": 0.5, "tipo_linea": "sólida"},
            "Const_N4": {"contorno": "#9fb6c3", "relleno": "#d4b5a5", "ancho": 0.5, "tipo_linea": "sólida"},
            "Const_N5": {"contorno": "#9fb6c3", "relleno": "#d4b5a5", "ancho": 0.5, "tipo_linea": "sólida"},
            "Const_N6": {"contorno": "#9fb6c3", "relleno": "#d4b5a5", "ancho": 0.5, "tipo_linea": "sólida"},
            "Bardas": {"contorno": "#ff7f00", "relleno": None, "ancho": 1.2, "tipo_linea": "sólida"},
            "Restriccion": {"contorno": "#000000", "relleno": "#c43c39", "ancho": 0.3, "tipo_linea": "sólida"},
        }

        # ---------------- CARGAR CAPAS Y APLICAR ESTILO VISUAL ----------------
        loaded_layers = []

        for file in os.listdir(shp_folder):
            if file.lower().endswith(".shp"):
                shp_path = os.path.join(shp_folder, file)
                layer_name = os.path.splitext(file)[0]

                layer = QgsVectorLayer(shp_path, layer_name, "ogr")

                if layer.isValid():
                    estilo = estilos_capas.get(layer_name)
                    if estilo:
                        # Solo para visualización, no toca la tabla
                        if layer.geometryType() == 2:  # Polígono
                            simbolo = QgsFillSymbol.createSimple({
                                "color": estilo["relleno"] if estilo["relleno"] else "transparent",
                                "outline_color": estilo["contorno"],
                                "outline_width": str(estilo["ancho"]),
                                "outline_style": obtener_estilo_linea(estilo["tipo_linea"])
                            })
                        else:  # Línea o punto
                            simbolo = QgsLineSymbol.createSimple({
                                "color": estilo["contorno"],
                                "width": str(estilo["ancho"]),
                                "line_style": obtener_estilo_linea(estilo["tipo_linea"])
                            })
                        layer.setRenderer(QgsSingleSymbolRenderer(simbolo))
                        layer.triggerRepaint()
                        print(f"🎨 Estilo aplicado a: {layer_name}")

                    # QgsProject.instance().addMapLayer(layer)#
                    loaded_layers.append(layer)
                else:
                    print(f"⚠ No se pudo cargar la capa: {shp_path}")

        # ---------------- EXPORTAR GPKG SIN CREAR ID ----------------
        if loaded_layers:
            processing.run("native:package", {
                'LAYERS': loaded_layers,
                'OUTPUT': gpkg_path,
                'OVERWRITE': True,
                'SAVE_STYLES': True,   # guarda estilos visuales
                'SAVE_METADATA': True,
                'SELECTED_FEATURES_ONLY': False,
                'EXPORT_RELATED_LAYERS': False
            })
            print(f"✅ GeoPackage creado con {len(loaded_layers)} capas:\n{gpkg_path}")

            for layer in loaded_layers:
                layer.deleteLater()
            loaded_layers.clear()
            print("🗑 Capas liberadas de memoria.")
            
            QMessageBox.information(self.iface.mainWindow(), "¡Éxito!", f"Proceso finalizado correctamente.\nGeoPackage guardado en:\n{gpkg_path}")
        else:
            print("❌ No se encontraron capas válidas para empaquetar.")
            QMessageBox.warning(self.iface.mainWindow(), "Atención", "No se encontraron capas válidas para empaquetar.")