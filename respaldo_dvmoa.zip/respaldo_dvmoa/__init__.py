def classFactory(iface):
    from .respaldo_dvmoa import ExportarIGECEMPlugin
    return ExportarIGECEMPlugin(iface)
