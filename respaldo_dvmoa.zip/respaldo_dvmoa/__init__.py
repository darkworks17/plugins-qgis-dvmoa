def classFactory(iface):
    from .respaldo_dvmoa import RespaldoDvmoa
    return RespaldoDvmoa(iface)
