def classFactory(iface):
    from .editar_etiquetas_plugin import EditarEtiquetasDVMOAPlugin
    return EditarEtiquetasDVMOAPlugin(iface)
