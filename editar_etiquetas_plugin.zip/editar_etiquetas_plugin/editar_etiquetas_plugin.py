import os
from PyQt5.QtGui import QIcon
from qgis.PyQt.QtCore import Qt
# Se agregó QMenu a la importación
from qgis.PyQt.QtWidgets import QInputDialog, QMessageBox, QAction, QLineEdit, QMenu
from qgis.gui import QgsMapToolIdentifyFeature
from qgis.core import (
    QgsProject,
    QgsPalLayerSettings,
    QgsTextFormat,
    QgsVectorLayerSimpleLabeling,
    QgsTextBufferSettings,
    QgsFontUtils,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsRectangle,
    QgsFeatureRequest,
    QgsGeometry,
    QgsFeature
)

# ============================================================
# CLASE DE LA HERRAMIENTA DE MAPA (MAP TOOL)
# ============================================================
class EditLabelTool(QgsMapToolIdentifyFeature):
    def __init__(self, canvas, layer, field_name, original_renderer, original_label_state, parent_window):
        super().__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.field_name = field_name
        self.original_renderer = original_renderer
        self.original_label_state = original_label_state
        self.parent_window = parent_window
        
        self.setLayer(self.layer)
        
        # Activar el modo de edición visual al seleccionar la herramienta
        self.activar_etiquetas()
        self.engrosar_linea()
        print(">> Herramienta de Edición ACTIVA.")

        # Cuando el usuario cambie a otra herramienta, restauramos todo
        self.deactivated.connect(self.restaurar_estilos)

    def activar_etiquetas(self):
        label_settings = QgsPalLayerSettings()
        label_settings.fieldName = self.field_name
        label_settings.placement = QgsPalLayerSettings.Line
        label_settings.placementFlags = QgsPalLayerSettings.OnLine
        
        # ¡ESTO ES CRÍTICO! Obliga a QGIS a mostrar la etiqueta aunque la línea sea corta
        label_settings.displayAll = True 
        
        text_format = QgsTextFormat()
        text_format.setSize(12)
        text_format.setFont(QgsFontUtils.getStandardTestFont("Arial"))
        
        buffer = QgsTextBufferSettings()
        buffer.setEnabled(True)
        buffer.setSize(1)
        text_format.setBuffer(buffer)
        
        label_settings.setFormat(text_format)
        
        self.layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
        self.layer.setLabelsEnabled(True)
        self.layer.triggerRepaint()

    def engrosar_linea(self):
        sym = QgsLineSymbol.createSimple({
            "color": "0,0,0",
            "width": "1.5" 
        })
        self.layer.setRenderer(QgsSingleSymbolRenderer(sym))
        self.layer.triggerRepaint()

    def restaurar_estilos(self):
        self.layer.removeSelection() # Limpiar selecciones si las hubiera
        self.layer.setLabelsEnabled(self.original_label_state)
        self.layer.setRenderer(self.original_renderer.clone())
        self.layer.triggerRepaint()
        print(">> Herramienta de Edición DESACTIVADA. Estilos restaurados.")

    def canvasReleaseEvent(self, event):
        if event.button() != Qt.LeftButton:
            return
            
        # 1. DEFINIR ÁREA DE BÚSQUEDA
        pixel_tolerance = 15 
        map_tolerance = self.canvas.mapUnitsPerPixel() * pixel_tolerance
        point = self.toMapCoordinates(event.pos())
        
        rect = QgsRectangle(
            point.x() - map_tolerance, point.y() - map_tolerance,
            point.x() + map_tolerance, point.y() + map_tolerance
        )
        
        request = QgsFeatureRequest().setFilterRect(rect)
        
        # 2. ENCONTRAR LA LÍNEA EXACTA MÁS CERCANA
        min_dist = float('inf')
        closest_feat = None
        point_geom = QgsGeometry.fromPointXY(point)
        
        for f in self.layer.getFeatures(request):
            if f.hasGeometry():
                dist = f.geometry().distance(point_geom)
                if dist < min_dist:
                    min_dist = dist
                    closest_feat = QgsFeature(f)
                    
        if not closest_feat:
            return

        fid = closest_feat.id()

        # ========================================================
        # MEJORA VISUAL: Resaltar la línea en amarillo para saber 
        # exactamente cuál vamos a editar.
        # ========================================================
        self.layer.removeSelection()
        self.layer.select(fid)
        self.canvas.refresh()

        # 3. OBTENER EL DATO REAL DE LA BASE DE DATOS
        fresh_feat = self.layer.getFeature(fid)
        current_text = fresh_feat.attribute(self.field_name)
        
        if current_text is None or str(current_text).strip() == '' or str(current_text).upper() == 'NULL':
            texto_mostrar = ""
        else:
            texto_mostrar = str(current_text)

        # 4. DIÁLOGO DE EDICIÓN
        new_text, ok = QInputDialog.getText(
            self.parent_window, 
            "Editar etiqueta",
            f"Texto para la calle seleccionada:",
            QLineEdit.Normal, # Fuerza a limpiar memorias de cuadros de texto anteriores
            texto_mostrar
        )

        # Quitamos el resaltado amarillo una vez que se cierra la ventana
        self.layer.removeSelection()

        if ok:
            idx = self.layer.fields().indexFromName(self.field_name)
            
            was_editing = self.layer.isEditable()
            if not was_editing:
                self.layer.startEditing()
            
            success = self.layer.changeAttributeValue(fid, idx, new_text)
            
            if success:
                if not was_editing:
                    self.layer.commitChanges()
                
                # Forzamos recarga gráfica absoluta
                self.layer.triggerRepaint()
                self.canvas.refresh()
            else:
                QMessageBox.warning(self.parent_window, "Error", "No se guardó el cambio.")
                if not was_editing:
                    self.layer.rollBack()
        else:
            # Si el usuario presiona "Cancelar", solo refrescamos para quitar lo amarillo
            self.canvas.refresh()

# ============================================================
# CLASE PRINCIPAL DEL PLUGIN
# ============================================================
class EditarEtiquetasDVMOAPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.tool = None
        self.dvmoa_menu = None # Variable para gestionar el menú superior

    def initGui(self):
        ruta_icono = os.path.join(os.path.dirname(__file__), "editar_etiquetas_plugin.png")
        self.action = QAction(QIcon(ruta_icono), "Editar Etiquetas (Ejes de linea)", self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.triggered.connect(self.run)
        
        # --- LÓGICA DE MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        # Revisamos si el menú "&DVMOA" ya fue creado por otra de tus herramientas
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si no existe, lo creamos
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        # Agregamos nuestra acción a este menú principal
        self.dvmoa_menu.addAction(self.action)
        
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Removemos la acción del menú principal creado
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            # Si el menú se queda sin botones, lo eliminamos
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
                
        self.iface.removeToolBarIcon(self.action)
        if self.tool and self.iface.mapCanvas().mapTool() == self.tool:
            self.iface.mapCanvas().unsetMapTool(self.tool)

    def run(self, checked):
        canvas = self.iface.mapCanvas()
        
        if not checked:
            if canvas.mapTool() == self.tool:
                self.iface.actionPan().trigger() 
            return

        layer_name = "Ejes de linea"
        field_name = "calle"

        layer_list = QgsProject.instance().mapLayersByName(layer_name)
        if not layer_list:
            QMessageBox.warning(self.iface.mainWindow(), "Aviso", f"No se encontró la capa '{layer_name}'")
            self.action.setChecked(False)
            return
            
        layer = layer_list[0]

        real_field_name = None
        for f in layer.fields():
            if f.name().lower() == field_name.lower():
                real_field_name = f.name()
                break

        if not real_field_name:
            QMessageBox.warning(self.iface.mainWindow(), "Aviso", f"La capa '{layer_name}' no tiene el campo '{field_name}'")
            self.action.setChecked(False)
            return

        original_renderer = layer.renderer().clone()
        original_label_state = layer.labelsEnabled()

        self.tool = EditLabelTool(
            canvas, 
            layer, 
            real_field_name, 
            original_renderer, 
            original_label_state, 
            self.iface.mainWindow()
        )
        canvas.setMapTool(self.tool)
        self.tool.deactivated.connect(lambda: self.action.setChecked(False))