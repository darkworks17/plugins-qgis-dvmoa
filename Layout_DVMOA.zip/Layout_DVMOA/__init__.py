def classFactory(iface):
    from .Layout_DVMOA import LayoutDVMOAPlugin
    return LayoutDVMOAPlugin(iface)
