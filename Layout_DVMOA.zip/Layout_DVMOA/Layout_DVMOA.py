import os
from datetime import datetime
from openpyxl import Workbook

from qgis.core import QgsProject
from qgis.PyQt.QtWidgets import QAction, QMenu, QMessageBox
from qgis.PyQt.QtGui import QIcon

class LayoutDVMOAPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dvmoa_menu = None  # Variable para gestionar el menú superior

    def initGui(self):
        # Nombre del icono
        icon_path = os.path.join(self.plugin_dir, 'Layout_DVMOA.png')
        # ---> CAMBIÓ DEL NOMBRE <---
        self.action = QAction(QIcon(icon_path), "Generar Layout DVMOA", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # --- LÓGICA DE MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        # Revisamos si el menú "&DVMOA" ya fue creado por otra de tus herramientas
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si no existe, lo creamos
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        # Agregamos nuestra acción a este menú principal
        self.dvmoa_menu.addAction(self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Removemos la acción del menú principal creado
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            # Si el menú se queda sin botones, lo eliminamos
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
                
        self.iface.removeToolBarIcon(self.action)
        del self.action

    def run(self):
        # ------------------------------------------------------------
        # 1. CONFIGURACIÓN
        # ------------------------------------------------------------
        CAPA_PREDIOS = "Predios"

        TABLAS_CONSTRUCCIONES = [
            "Const_N1", "Const_N2", "Const_N3", "Const_N4", "Const_N5",
            "Const_N6", "Const_N7", "Const_N8", "Const_N9", "Const_N10",
            "Const_S1", "Const_S2", "Const_S3",
            "Bardas", "Marquesina", "Voladizos"
        ]

        # Mapeo de columnas para la hoja de Predios
        mapping_predios = {
            "CLAVECATASTRAL": "CLAVECATAS",
            "CLAVEENTIDAD_PRE": "CVEENTPRE",
            "CLAVEMUNICIPIO_PRE": "CVEMUNPRE",
            "CLAVEASENTAMIENTO_PRE": "CVEASEPRE",
            "CLAVECP_PRE": "CVECPPRE",
            "ASENTAMIENTO_NR_PRE": "ASENRPRE",
            "CLAVECP_NR_PRE": "CVECPNRPRE",
            "CALLE_PRE": "CALLEPRE",
            "NOEXTERIOR_PRE": "NOEXTPRE",
            "NOINTERIOR_PRE": "NOINTPRE",
            "USOESPECIFICO": "USOESP",
            "NOMBRE": "NOMBRE",
            "APATERNO": "APATERNO",
            "AMATERNO": "AMATERNO",
            "RFC": "RFC",
            "CURP": "CURP",
            "CLAVEENTIDAD_PRO": "CVEENTPRO",
            "CLAVEMUNICIPIO_PRO": "CVEMUNPRO",
            "CLAVEASENTAMIENTO_PRO": "CVEASEPRO",
            "CLAVECP_PRO": "CVECPPRO",
            "ASENTAMIENTO_NR_PRO": "ASENRPRO",
            "CLAVECP_NR_PRO": "CVECPNRPRO",
            "CALLE_PRO": "CALLEPRO",
            "NOEXTERIOR_PRO": "NOEXTPRO",
            "NOINTERIOR_PRO": "NOINTPRO",
            "LADA": "LADA",
            "TELEFONO": "TELEFONO",
            "CLAVEREGIMEN": "CVEREGIMEN",
            "INDIVISO": "INDIVISO",
            "CODAREAHOMOGENEA": "CODAREAHOM",
            "CLAVEUSOAREAHOMO": "CVEUSOAHOM",
            "CLAVEUSO": "CVEUSO",
            "CLAVEPOSICION": "CVEPOSICIO",
            "CLAVEFORMA": "CVEFORMA",
            "AREAINSCRITA": "AREAINSCRI",
            "CLAVETOPOGRAFIA": "CVETOPOGRA",
            "DESNIVEL": "DESNIVEL",
            "FRENTE": "FRENTE",
            "FONDO": "FONDO",
            "FONDOBASE": "FONDOBASE",
            "AREABASE": "AREABASE",
            "VALORUNITARIOSUELO": "VALUNISUE",
            "SUPPRIVATIVO": "SUPPRIVATI",
            "SUPCOMUN": "SUPCOMUN",
            "CLAVEOBSERVACION": "CVEOBSERV",
            "OBSERVACIONES": "OBSERVACIO",
            "NUMOFICIO": "NUMOFICIO",
            "VALOR CATASTRAL": "VALCATASTR"
        }

        # Mapeo columnas de construcciones
        mapping_construcciones = {
            "CLAVECATASTRAL": "CLAVECATAS",
            "ID_CONSTRUCCION": "ID_CONSTR",
            "CLAVETIPO": "CLAVETIPO",
            "CLAVECLASIFICACION": "CVECLASIF",
            "SUPERFICIE": "SUPERFICIE",
            "EDAD": "EDAD",
            "CLAVECONSERVACION": "CVECONSERV",
            "NIVELES": "NIVELES",
            "ALTURA": "ALTURA"
        }

        # ------------------------------------------------------------
        # 2. CARGAR CAPA PREDIOS
        # ------------------------------------------------------------
        layers_predios = QgsProject.instance().mapLayersByName(CAPA_PREDIOS)
        if not layers_predios:
            QMessageBox.critical(self.iface.mainWindow(), "Error", f"No se encontró la capa '{CAPA_PREDIOS}'.")
            return
            
        layer_predios = layers_predios[0]

        # ------------------------------------------------------------
        # 3. FILTRAR SOLO "PROCEDENTES"
        # ------------------------------------------------------------
        features_predios = [f for f in layer_predios.getFeatures() if str(f["ESTATUS"]).upper() == "PROCEDENTE"]

        if not features_predios:
            QMessageBox.warning(self.iface.mainWindow(), "Atención", "No hay predios con ESTATUS = 'PROCEDENTE'.")
            return

        # ------------------------------------------------------------
        # 4. FUNCION LIMPIAR
        # ------------------------------------------------------------
        def limpiar(valor):
            if valor is None:
                return ""
            if str(valor).upper() == "NULL":
                return ""
            return valor

        # ------------------------------------------------------------
        # 5. CREAR EXCEL
        # ------------------------------------------------------------
        self.iface.messageBar().pushMessage("Procesando", "Generando archivos...", level=0, duration=3)
        
        wb = Workbook()
        ws_predios = wb.active
        ws_predios.title = "Layout Datos Predio"

        ws_predios.append(list(mapping_predios.keys()))

        for f in features_predios:
            fila = []
            for excel_col, layer_col in mapping_predios.items():
                if layer_col == "SD":
                    fila.append("")
                else:
                    try:
                        fila.append(limpiar(f[layer_col]))
                    except:
                        fila.append("")
            ws_predios.append(fila)

        # ------------------------------------------------------------
        # 6. HOJA DE CONSTRUCCIONES
        # ------------------------------------------------------------
        ws_cons = wb.create_sheet("Layout Datos Construcciones")
        ws_cons.append(list(mapping_construcciones.keys()))

        capas_cons = {}
        for nombre in TABLAS_CONSTRUCCIONES:
            lista = QgsProject.instance().mapLayersByName(nombre)
            if lista:
                capas_cons[nombre] = lista[0]

        # También almacenamos valores para TXT
        txt_predios_lineas = []
        txt_constru_lineas = []

        # ------------------------------------------------------------
        # 7. TXT Predios
        # ------------------------------------------------------------
        for f in features_predios:
            valores = []
            for excel_col, layer_col in mapping_predios.items():
                if layer_col == "SD":
                    valores.append("")
                else:
                    try:
                        valores.append(str(limpiar(f[layer_col])))
                    except:
                        valores.append("")
            txt_predios_lineas.append("|".join(valores))

        # ------------------------------------------------------------
        # 8. TXT Construcciones + Excel
        # ------------------------------------------------------------
        for predio in features_predios:
            clave = predio["CLAVECATAS"]
            lista_constr = []

            for nombre, capa in capas_cons.items():
                for c in capa.getFeatures():
                    if str(c["CLAVECATAS"]) == clave:
                        lista_constr.append(c)

            lista_constr.sort(key=lambda x: x["ID_CONSTR"])

            for cons in lista_constr:
                fila = []
                valores_txt = []

                for excel_col, layer_col in mapping_construcciones.items():
                    try:
                        val = limpiar(cons[layer_col])
                    except:
                        val = ""

                    fila.append(val)
                    valores_txt.append(str(val))

                ws_cons.append(fila)
                txt_constru_lineas.append("|".join(valores_txt))

        # ------------------------------------------------------------
        # 9. GUARDAR ARCHIVOS
        # ------------------------------------------------------------
        clave = str(features_predios[0]["CLAVECATAS"])
        prefijo = clave[:3]
        fecha = datetime.now().strftime("%d-%m-%Y")

        # Excel
        nombre_excel = f"ReporteSIGCAT_{prefijo}_{fecha}.xlsx"
        ruta_excel = os.path.join(os.path.expanduser("~"), "Desktop", nombre_excel)

        if os.path.exists(ruta_excel):
            try:
                os.remove(ruta_excel)
            except Exception as e:
                QMessageBox.critical(self.iface.mainWindow(), "Error", f"Cierre el archivo Excel antes de generar uno nuevo:\n{e}")
                return

        wb.save(ruta_excel)

        # TXT PREDIOS
        nombre_txt_predios = f"Predios_SIGCAT_{prefijo}_{fecha}.txt"
        ruta_txt_predios = os.path.join(os.path.expanduser("~"), "Desktop", nombre_txt_predios)

        with open(ruta_txt_predios, "w", encoding="utf-8") as f:
            for linea in txt_predios_lineas:
                f.write(linea + "\n")

        # TXT CONSTRUCCIONES
        nombre_txt_cons = f"Construcciones_SIGCAT_{prefijo}_{fecha}.txt"
        ruta_txt_cons = os.path.join(os.path.expanduser("~"), "Desktop", nombre_txt_cons)

        with open(ruta_txt_cons, "w", encoding="utf-8") as f:
            for linea in txt_constru_lineas:
                f.write(linea + "\n")

        # Mensaje final
        msg = f"Archivos generados exitosamente en el Escritorio:\n\n1. {nombre_excel}\n2. {nombre_txt_predios}\n3. {nombre_txt_cons}"
        QMessageBox.information(self.iface.mainWindow(), "Proceso Terminado", msg)