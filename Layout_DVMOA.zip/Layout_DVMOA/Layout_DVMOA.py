import os
from datetime import datetime

# Importamos xlsxwriter (recuerda pegar la carpeta en tu plugin)
try:
    import xlsxwriter
except ImportError:
    pass

from qgis.core import QgsProject
from qgis.PyQt.QtWidgets import QAction, QMenu, QMessageBox, QFileDialog
from qgis.PyQt.QtGui import QIcon

class LayoutDVMOAPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dvmoa_menu = None  # Menú superior

    def initGui(self):
        # Icono
        icon_path = os.path.join(self.plugin_dir, 'Layout_DVMOA.png')
        self.action = QAction(QIcon(icon_path), "Generar Layout DVMOA", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # --- MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        # Menú "&DVMOA"
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si no existe, lo creamos
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        # Menú principal
        self.dvmoa_menu.addAction(self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Menú principal
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            # Menú sin botones
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
                
        self.iface.removeToolBarIcon(self.action)
        if self.action:
            del self.action

    def run(self):
        # ------------------------------------------------------------
        # 1. CONFIGURACIÓN
        # ------------------------------------------------------------
        CAPA_PREDIOS = "Predios"

        TABLAS_CONSTRUCCIONES = [
            "Const_N1", "Const_N2", "Const_N3", "Const_N4", "Const_N5",
            "Const_N6", "Const_N7", "Const_N8", "Const_N9", "Const_N10",
            "Const_S1", "Const_S2", "Const_S3",
            "Bardas", "Marquesina", "Voladizos"
        ]

        # Mapeo de columnas
        mapping_predios = {
            "CLAVECATASTRAL": "CLAVECATAS", "CLAVEENTIDAD_PRE": "CVEENTPRE",
            "CLAVEMUNICIPIO_PRE": "CVEMUNPRE", "CLAVEASENTAMIENTO_PRE": "CVEASEPRE",
            "CLAVECP_PRE": "CVECPPRE", "ASENTAMIENTO_NR_PRE": "ASENRPRE",
            "CLAVECP_NR_PRE": "CVECPNRPRE", "CALLE_PRE": "CALLEPRE",
            "NOEXTERIOR_PRE": "NOEXTPRE", "NOINTERIOR_PRE": "NOINTPRE",
            "USOESPECIFICO": "USOESP", "NOMBRE": "NOMBRE",
            "APATERNO": "APATERNO", "AMATERNO": "AMATERNO",
            "RFC": "RFC", "CURP": "CURP",
            "CLAVEENTIDAD_PRO": "CVEENTPRO", "CLAVEMUNICIPIO_PRO": "CVEMUNPRO",
            "CLAVEASENTAMIENTO_PRO": "CVEASEPRO", "CLAVECP_PRO": "CVECPPRO",
            "ASENTAMIENTO_NR_PRO": "ASENRPRO", "CLAVECP_NR_PRO": "CVECPNRPRO",
            "CALLE_PRO": "CALLEPRO", "NOEXTERIOR_PRO": "NOEXTPRO",
            "NOINTERIOR_PRO": "NOINTPRO", "LADA": "LADA",
            "TELEFONO": "TELEFONO", "CLAVEREGIMEN": "CVEREGIMEN",
            "INDIVISO": "INDIVISO", "CODAREAHOMOGENEA": "CODAREAHOM",
            "CLAVEUSOAREAHOMO": "CVEUSOAHOM", "CLAVEUSO": "CVEUSO",
            "CLAVEPOSICION": "CVEPOSICIO", "CLAVEFORMA": "CVEFORMA",
            "AREAINSCRITA": "AREAINSCRI", "CLAVETOPOGRAFIA": "CVETOPOGRA",
            "DESNIVEL": "DESNIVEL", "FRENTE": "FRENTE",
            "FONDO": "FONDO", "FONDOBASE": "FONDOBASE",
            "AREABASE": "AREABASE", "VALORUNITARIOSUELO": "VALUNISUE",
            "SUPPRIVATIVO": "SUPPRIVATI", "SUPCOMUN": "SUPCOMUN",
            "CLAVEOBSERVACION": "CVEOBSERV", "OBSERVACIONES": "OBSERVACIO",
            "NUMOFICIO": "NUMOFICIO", "VALOR CATASTRAL": "VALCATASTR"
        }

        # Mapeo columnas de construcciones
        mapping_construcciones = {
            "CLAVECATASTRAL": "CLAVECATAS", "ID_CONSTRUCCION": "ID_CONSTR",
            "CLAVETIPO": "CLAVETIPO", "CLAVECLASIFICACION": "CVECLASIF",
            "SUPERFICIE": "SUPERFICIE", "EDAD": "EDAD",
            "CLAVECONSERVACION": "CVECONSERV", "NIVELES": "NIVELES",
            "ALTURA": "ALTURA"
        }

        # ------------------------------------------------------------
        # 2. CARGAR CAPA PREDIOS
        # ------------------------------------------------------------
        layers_predios = QgsProject.instance().mapLayersByName(CAPA_PREDIOS)
        if not layers_predios:
            QMessageBox.critical(self.iface.mainWindow(), "Error", f"No se encontró la capa '{CAPA_PREDIOS}'.")
            return
            
        layer_predios = layers_predios[0]

        # ------------------------------------------------------------
        # 3. FILTRAR SOLO "PROCEDENTES"
        # ------------------------------------------------------------
        features_predios = [f for f in layer_predios.getFeatures() if str(f["ESTATUS"]).upper() == "PROCEDENTE"]

        if not features_predios:
            QMessageBox.warning(self.iface.mainWindow(), "Atención", "No hay predios con ESTATUS = 'PROCEDENTE'.")
            return

        # ------------------------------------------------------------
        # 4. FUNCION LIMPIAR
        # ------------------------------------------------------------
        def limpiar(valor):
            if valor is None:
                return ""
            if str(valor).upper() == "NULL":
                return ""
            return valor

        # ------------------------------------------------------------
        # 5. VENTANA
        # ------------------------------------------------------------
        self.iface.messageBar().pushMessage("Procesando", "Preparando archivos...", level=0, duration=2)
        
        clave = str(features_predios[0]["CLAVECATAS"])
        prefijo = clave[:3]
        fecha = datetime.now().strftime("%d-%m-%Y")

        nombre_sugerido = f"ReporteSIGCAT_{prefijo}_{fecha}.xlsx"
        
        # Guardar el Excel
        ruta_excel, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 
            "Guardar Reporte SIGCAT", 
            nombre_sugerido, 
            "Excel (*.xlsx)"
        )
        
        if not ruta_excel:
            return  # El usuario canceló

        # Rutas para los TXT en la misma carpeta que el Excel
        carpeta_elegida = os.path.dirname(ruta_excel)
        nombre_base = os.path.splitext(os.path.basename(ruta_excel))[0]
        
        ruta_txt_p = os.path.join(carpeta_elegida, f"{nombre_base}_Predios.txt")
        ruta_txt_c = os.path.join(carpeta_elegida, f"{nombre_base}_Construcciones.txt")

        # ------------------------------------------------------------
        # 6. CREAR EXCEL
        # ------------------------------------------------------------
        self.iface.messageBar().pushMessage("Procesando", "Generando Reporte...", level=0, duration=3)
        
        # Validar si el archivo Excel elegido ya existe y está abierto
        if os.path.exists(ruta_excel):
            try:
                os.remove(ruta_excel)
            except Exception as e:
                QMessageBox.critical(self.iface.mainWindow(), "Error", f"Cierre el archivo Excel antes de reemplazarlo:\n{e}")
                return

        workbook = xlsxwriter.Workbook(ruta_excel)
        
        # --- HOJA PREDIOS ---
        ws_predios = workbook.add_worksheet("Layout Datos Predio")

        # Encabezados
        for col_num, header in enumerate(mapping_predios.keys()):
            ws_predios.write(0, col_num, header)

        # Datos
        for row_num, f in enumerate(features_predios, start=1):
            for col_num, (excel_col, layer_col) in enumerate(mapping_predios.items()):
                if layer_col == "SD":
                    ws_predios.write(row_num, col_num, "")
                else:
                    try:
                        val = limpiar(f[layer_col])
                    except:
                        val = ""
                    ws_predios.write(row_num, col_num, val)

        # --- HOJA ---
        ws_cons = workbook.add_worksheet("Layout Datos Construcciones")

        # Encabezados
        for col_num, header in enumerate(mapping_construcciones.keys()):
            ws_cons.write(0, col_num, header)

        capas_cons = {}
        for nombre in TABLAS_CONSTRUCCIONES:
            lista = QgsProject.instance().mapLayersByName(nombre)
            if lista:
                capas_cons[nombre] = lista[0]

        txt_predios_lineas = []
        txt_constru_lineas = []

        # ------------------------------------------------------------
        # 7. TXT PREDIOS
        # ------------------------------------------------------------
        for f in features_predios:
            valores = []
            for excel_col, layer_col in mapping_predios.items():
                if layer_col == "SD":
                    valores.append("")
                else:
                    try:
                        valores.append(str(limpiar(f[layer_col])))
                    except:
                        valores.append("")
            txt_predios_lineas.append("|".join(valores))

        # ------------------------------------------------------------
        # 8. TXT CONSTRUCCIONES Y EXCEL CONSTRUCCIONES
        # ------------------------------------------------------------
        row_cons = 1
        for predio in features_predios:
            clave = predio["CLAVECATAS"]
            lista_constr = []

            for nombre, capa in capas_cons.items():
                for c in capa.getFeatures():
                    if str(c["CLAVECATAS"]) == clave:
                        lista_constr.append(c)

            lista_constr.sort(key=lambda x: x["ID_CONSTR"])

            for cons in lista_constr:
                valores_txt = []
                for col_num, (excel_col, layer_col) in enumerate(mapping_construcciones.items()):
                    try:
                        val = limpiar(cons[layer_col])
                    except:
                        val = ""

                    ws_cons.write(row_cons, col_num, val)
                    valores_txt.append(str(val))
                
                row_cons += 1
                txt_constru_lineas.append("|".join(valores_txt))

        # ------------------------------------------------------------
        # 9. GUARDAR ARCHIVOS
        # ------------------------------------------------------------
        
        # Cerrar el Excel
        workbook.close()

        # TXT PREDIOS
        with open(ruta_txt_p, "w", encoding="utf-8") as f:
            for linea in txt_predios_lineas:
                f.write(linea + "\n")

        # TXT CONSTRUCCIONES
        with open(ruta_txt_c, "w", encoding="utf-8") as f:
            for linea in txt_constru_lineas:
                f.write(linea + "\n")

        # Mensaje final
        msg = f"Archivos generados exitosamente en:\n{carpeta_elegida}\n\n1. {os.path.basename(ruta_excel)}\n2. {os.path.basename(ruta_txt_p)}\n3. {os.path.basename(ruta_txt_c)}"
        QMessageBox.information(self.iface.mainWindow(), "Proceso Terminado", msg)