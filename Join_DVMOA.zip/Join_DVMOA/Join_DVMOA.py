import os
import processing
from qgis.core import QgsProject, QgsVectorLayer
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox, QMenu
from qgis.PyQt.QtGui import QIcon
from qgis.utils import iface

class JoinDVMOAPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dvmoa_menu = None

    def initGui(self):
        # 1. Configurar
        icon_path = os.path.join(self.plugin_dir, 'Join_DVMOA.png')
        self.action = QAction(QIcon(icon_path), "Join DVMOA (Unir Capas)", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # 2. Menú superior &DVMOA
        menu_bar = self.iface.mainWindow().menuBar()
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si el menú no existe
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        self.dvmoa_menu.addAction(self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Limpiar la interfaz
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
                
        self.iface.removeToolBarIcon(self.action)
        if self.action:
            del self.action

    def run(self):
        # 1. Abrir ventana para seleccionar los archivos de entrada
        rutas_archivos, _ = QFileDialog.getOpenFileNames(
            self.iface.mainWindow(), 
            "Paso 1: Selecciona los archivos a cargar y unir", 
            "",
            "Archivos Vectoriales (*.shp *.gpkg *.geojson *.kml);;Todos los archivos (*.*)"
        )

        if not rutas_archivos:
            self.iface.messageBar().pushMessage("Cancelado", "No seleccionaste archivos de entrada.", level=1, duration=3)
            return

        # 2. Abrir ventana para decidir dónde guardar el GeoPackage final
        ruta_guardado, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 
            "Paso 2: ¿Dónde quieres guardar el GeoPackage y el Proyecto de QGIS?", 
            "Resultado_Unificado.gpkg",
            "GeoPackage (*.gpkg)"
        )

        if not ruta_guardado:
            self.iface.messageBar().pushMessage("Cancelado", "No seleccionaste dónde guardar el resultado.", level=1, duration=3)
            return

        # Extensiones correctas
        if not ruta_guardado.endswith('.gpkg'):
            ruta_guardado += '.gpkg'
        
        # Ruta del proyecto
        ruta_proyecto = ruta_guardado.replace('.gpkg', '.qgz')

        self.iface.messageBar().pushMessage("Procesando", "Cargando y evaluando capas...", level=0, duration=3)
        proyecto = QgsProject.instance()
        capas_originales = []

        # 3. Cargar todos los archivos seleccionados
        for ruta in rutas_archivos:
            nombre_base = os.path.splitext(os.path.basename(ruta))[0]
            capa = QgsVectorLayer(ruta, nombre_base, "ogr")
            
            if capa.isValid():
                proyecto.addMapLayer(capa)
                capas_originales.append(capa)
            else:
                self.iface.messageBar().pushMessage("Error", f"Fallo al cargar: {ruta}", level=2, duration=4)

        # 4. Agrupar las capas
        capas_por_nombre = {}
        for capa in capas_originales:
            nombre = capa.name()
            if nombre not in capas_por_nombre:
                capas_por_nombre[nombre] = []
            capas_por_nombre[nombre].append(capa)

        capas_para_empaquetar = []

        # 5. Unir las capas repetidas
        for nombre, lista_capas in capas_por_nombre.items():
            if len(lista_capas) > 1:
                self.iface.messageBar().pushMessage("Procesando", f"Fusionando {len(lista_capas)} capas llamadas '{nombre}'...", level=0, duration=2)
                parametros = {
                    'LAYERS': lista_capas,
                    'CRS': lista_capas[0].crs(), 
                    'OUTPUT': 'memory:' + nombre # Memoria temporal
                }
                resultado = processing.run("native:mergevectorlayers", parametros)
                capa_unida = resultado['OUTPUT']
                capa_unida.setName(nombre) # Nombre original
                proyecto.addMapLayer(capa_unida)
                capas_para_empaquetar.append(capa_unida)
                
                # Borrar del panel las capas individuales sueltas
                for capa_orig in lista_capas:
                    proyecto.removeMapLayer(capa_orig.id())
                    
            elif len(lista_capas) == 1:
                # Si la capa no estaba repetida
                capas_para_empaquetar.append(lista_capas[0])

        # 6. Guardar GeoPackage
        if capas_para_empaquetar:
            self.iface.messageBar().pushMessage("Empaquetando", "Guardando capas en el nuevo GeoPackage...", level=0, duration=3)
            parametros_paquete = {
                'LAYERS': capas_para_empaquetar,
                'OUTPUT': ruta_guardado,
                'OVERWRITE': True,
                'SAVE_STYLES': False,
                'SAVE_METADATA': False,
                'SELECTED_FEATURES_ONLY': False
            }
            processing.run("native:package", parametros_paquete)

            # 7. Capas temporales por las definitivas
            for capa_memoria in capas_para_empaquetar:
                nombre_capa = capa_memoria.name()
                proyecto.removeMapLayer(capa_memoria.id())
                
                uri_gpkg = f"{ruta_guardado}|layername={nombre_capa}"
                capa_definitiva = QgsVectorLayer(uri_gpkg, nombre_capa, "ogr")
                if capa_definitiva.isValid():
                    proyecto.addMapLayer(capa_definitiva)

        # 8. Guardar el Proyecto de QGIS
        proyecto.write(ruta_proyecto)
        
        # 9. Mensaje Final
        mensaje_exito = (
            f"¡Proceso 100% completado!\n\n"
            f"✔️ GeoPackage guardado en:\n{ruta_guardado}\n\n"
            f"✔️ Proyecto QGIS guardado en:\n{ruta_proyecto}"
        )
        QMessageBox.information(self.iface.mainWindow(), "Join DVMOA Terminado", mensaje_exito)