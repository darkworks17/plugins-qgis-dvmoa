def classFactory(iface):
    from .Join_DVMOA import JoinDVMOAPlugin
    return JoinDVMOAPlugin(iface)
