def classFactory(iface):
    from .importar_predios import ImportarPrediosCad
    return ImportarPrediosCad(iface)
