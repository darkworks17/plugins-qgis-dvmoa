import os
# Se agregó QMenu a la importación
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox, QMenu
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsProject, 
    QgsVectorLayer, 
    QgsGeometry, 
    QgsSpatialIndex, 
    QgsVectorLayerUtils,
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils,
    QgsWkbTypes
)
from qgis.utils import iface

class ImportarPrediosCad:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dvmoa_menu = None  # Variable para gestionar el menú superior

    def initGui(self):
        # AQUÍ BUSCARÁ TU IMAGEN EXACTAMENTE CON ESTE NOMBRE
        icon_path = os.path.join(self.plugin_dir, 'importar_predios.png')
        
        # El texto que sale al poner el mouse sobre el botón
        self.action = QAction(QIcon(icon_path), "Importar Predios desde CAD", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # --- LÓGICA DE MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        # Revisamos si el menú "&DVMOA" ya fue creado por otra de tus herramientas
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si no existe, lo creamos
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        # Agregamos nuestra acción a este menú principal
        self.dvmoa_menu.addAction(self.action)
        
        # 2. Añade el botón a la barra de herramientas principal
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Removemos la acción del menú principal creado
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            # Si el menú se queda sin botones, lo eliminamos
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
        
        # Elimina el botón de la barra de herramientas
        self.iface.removeToolBarIcon(self.action)
        del self.action

    def run(self):
        # ================= CONFIGURACIÓN =================
        capa_cad_lineas = "Predio"
        capas_textos_validas = ["Número_predio", "NÃºmero_predio", "Numero_predio"]
        nombre_capa_destino   = "Predios"
        campo_destino_predio  = "PREDIO"
        campo_clave_catastral = "CLAVECATAS"
        # =================================================

        proyecto = QgsProject.instance()
        
        # 1. Ventana para seleccionar archivo
        ruta_cad, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(), 
            "Selecciona tu archivo CAD", 
            "", 
            "Archivos CAD (*.dxf *.dwg);;Todos los archivos (*.*)"
        )
        
        if not ruta_cad:
            return # Si el usuario cancela, no hace nada
            
        self.iface.messageBar().pushMessage("Procesando", f"Leyendo archivo: {os.path.basename(ruta_cad)}", level=0, duration=3)
        
        # 2. Cargar capas virtuales
        uri_lineas = f"{ruta_cad}|layername=entities|geometrytype=LineString"
        uri_textos = f"{ruta_cad}|layername=entities|geometrytype=Point"
        
        capa_origen_lineas = QgsVectorLayer(uri_lineas, "Lineas_CAD", "ogr")
        capa_origen_textos = QgsVectorLayer(uri_textos, "Textos_CAD", "ogr")

        if not capa_origen_lineas.isValid() or not capa_origen_textos.isValid():
            QMessageBox.critical(self.iface.mainWindow(), "Error", "No se pudo leer el archivo CAD. Asegúrate de usar un .dxf cerrado.")
            return

        # 3. Capa Destino
        lista_dest = proyecto.mapLayersByName(nombre_capa_destino)
        if not lista_dest:
            QMessageBox.warning(self.iface.mainWindow(), "Atención", f"Falta la capa '{nombre_capa_destino}' en el panel de QGIS.")
            return
            
        capa_final = lista_dest[0]
        destino_es_multi = QgsWkbTypes.isMultiType(capa_final.wkbType())

        # 4. Extraer Textos
        index_textos = QgsSpatialIndex()
        diccionario_textos = {}
        
        for f in capa_origen_textos.getFeatures():
            if f.attribute("Layer") in capas_textos_validas:
                texto = f.attribute("Text")
                if texto and str(texto).strip() and str(texto) != 'NULL':
                    index_textos.addFeature(f)
                    diccionario_textos[f.id()] = str(texto).strip()

        if not diccionario_textos:
            QMessageBox.warning(self.iface.mainWindow(), "Atención", "No se extrajeron números. Revisa las capas de tu CAD.")
            return

        # 5. Edición y Geometría
        if not capa_final.isEditable():
            capa_final.startEditing()

        idx_predio = capa_final.fields().indexOf(campo_destino_predio)
        idx_clave  = capa_final.fields().indexOf(campo_clave_catastral)
        
        expresion_clave = None
        if idx_clave != -1:
            defn = capa_final.defaultValueDefinition(idx_clave)
            if defn.isValid() and defn.expression():
                expresion_clave = QgsExpression(defn.expression())
        
        nuevos_ids = []
        contador = 0
        
        for feature_linea in capa_origen_lineas.getFeatures():
            if feature_linea.attribute("Layer") != capa_cad_lineas:
                continue
                
            geom_linea = feature_linea.geometry()
            if geom_linea.isNull():
                continue
                
            geom_poligono = None
            if not geom_linea.isMultipart():
                linea_puntos = geom_linea.asPolyline() 
                if len(linea_puntos) >= 3:
                    if linea_puntos[0] != linea_puntos[-1]:
                        linea_puntos.append(linea_puntos[0])
                    geom_poligono = QgsGeometry.fromPolygonXY([linea_puntos])
            
            if not geom_poligono:
                continue

            if destino_es_multi:
                geom_final = QgsGeometry.fromMultiPolygonXY([geom_poligono.asPolygon()])
            else:
                geom_final = geom_poligono

            # Cruce espacial
            candidatos_ids = index_textos.intersects(geom_final.boundingBox())
            texto_encontrado = None
            
            for txt_id in candidatos_ids:
                feat_txt = capa_origen_textos.getFeature(txt_id)
                if geom_final.contains(feat_txt.geometry()):
                    texto_encontrado = diccionario_textos[txt_id]
                    break 
            
            if texto_encontrado:
                atts = {idx_predio: texto_encontrado}
                nueva_entidad = QgsVectorLayerUtils.createFeature(capa_final, geom_final, atts)
                
                if expresion_clave:
                    context = QgsExpressionContext()
                    context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(capa_final))
                    context.setFeature(nueva_entidad)
                    valor_clave = expresion_clave.evaluate(context)
                    if valor_clave:
                        nueva_entidad.setAttribute(idx_clave, valor_clave)

                capa_final.addFeature(nueva_entidad)
                nuevos_ids.append(nueva_entidad.id())
                contador += 1

        # 6. Guardar automáticamente y Notificar
        if nuevos_ids:
            capa_final.commitChanges() 
            capa_final.triggerRepaint()
            self.iface.setActiveLayer(capa_final)
            
            # Mensaje de éxito visual
            QMessageBox.information(
                self.iface.mainWindow(), 
                "¡Proceso Exitoso!", 
                f"Se han importado y guardado correctamente {contador} predios en la capa '{nombre_capa_destino}'."
            )
        else:
            capa_final.rollBack() 
            QMessageBox.warning(self.iface.mainWindow(), "Atención", "Se leyeron los datos, pero ningún número cayó dentro de un polígono cerrado.")