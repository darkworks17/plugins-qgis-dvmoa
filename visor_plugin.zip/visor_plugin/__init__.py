def classFactory(iface):
    from .visor_plugin import VisorDVMOAPlugin
    return VisorDVMOAPlugin(iface)
