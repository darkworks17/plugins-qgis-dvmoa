import os
# Se agregó QMenu a la importación
from PyQt5.QtWidgets import (QFileDialog, QAction, QDialog, QVBoxLayout, 
                             QHBoxLayout, QLabel, QPushButton, QGraphicsView, 
                             QGraphicsScene, QGraphicsPixmapItem, QApplication, QShortcut, QMenu)
from PyQt5.QtGui import QIcon, QPixmap, QPainter, QKeySequence
from PyQt5.QtCore import Qt, QTimer
from qgis.core import (QgsProject, QgsExpressionContextUtils, QgsFeatureRequest, 
                       QgsGeometry, QgsCoordinateTransform)
from qgis.gui import QgsMapToolEmitPoint


# ==========================================
# 1. VISOR DE IMÁGENES MEJORADO (Evita el scroll)
# ==========================================
class VisorGraphicsView(QGraphicsView):
    def __init__(self, scene, parent=None):
        super().__init__(scene, parent)
        self.setRenderHint(QPainter.Antialiasing)
        self.setRenderHint(QPainter.SmoothPixmapTransform)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorUnderMouse)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setBackgroundBrush(Qt.black)

    # Al interceptar aquí el evento, evitamos el "salto" vertical al alejar
    def wheelEvent(self, event):
        factor = 1.15
        if event.angleDelta().y() > 0:
            self.scale(factor, factor)
        else:
            self.scale(1 / factor, 1 / factor)

# ==========================================
# 2. DIÁLOGO DEL VISOR (Diseño Windows 11)
# ==========================================
class VisorFotos(QDialog):
    def __init__(self, lista_archivos, indice_inicial, parent=None):
        super().__init__(parent)
        self.setWindowTitle("DVMOA_VISOR - Visualizador")
        
        # Tamaño dinámico basado en la pantalla
        pantalla = QApplication.primaryScreen().geometry()
        ancho = int(pantalla.width() * 0.75)  
        alto = int(pantalla.height() * 0.75)  
        self.resize(ancho, alto)
        
        self.archivos = lista_archivos
        self.indice = indice_inicial
        self.init_ui()
        QTimer.singleShot(10, self.cargar_imagen)

    def init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 10) # Margen limpio
        self.setLayout(layout)
        self.setStyleSheet("background-color: #202020; color: white;")
        
        self.scene = QGraphicsScene()
        self.view = VisorGraphicsView(self.scene)
        layout.addWidget(self.view)

        self.lbl_info = QLabel("")
        self.lbl_info.setStyleSheet("font-weight: bold; font-size: 14px; padding: 5px;")
        self.lbl_info.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.lbl_info)

        # Controles Estilo Windows 11
        btn_layout = QHBoxLayout()
        style_btn = """
            QPushButton { 
                background-color: transparent; 
                color: #e0e0e0; 
                border-radius: 8px; 
                padding: 5px 20px; 
                font-size: 20px; 
            }
            QPushButton:hover { 
                background-color: rgba(255, 255, 255, 0.15); 
                color: white;
            }
            QPushButton:pressed { 
                background-color: rgba(255, 255, 255, 0.25); 
            }
        """
        
        self.btn_prev = QPushButton("❮")
        self.btn_prev.setToolTip("Anterior (Flecha Izquierda)")
        self.btn_prev.setStyleSheet(style_btn)
        self.btn_prev.clicked.connect(self.prev_image)
        
        self.btn_reset = QPushButton("⛶")
        self.btn_reset.setToolTip("Ajustar a Ventana")
        self.btn_reset.setStyleSheet(style_btn + "font-size: 24px;")
        self.btn_reset.clicked.connect(self.ajustar_vista)
        
        self.btn_next = QPushButton("❯")
        self.btn_next.setToolTip("Siguiente (Flecha Derecha)")
        self.btn_next.setStyleSheet(style_btn)
        self.btn_next.clicked.connect(self.next_image)

        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_prev)
        btn_layout.addWidget(self.btn_reset)
        btn_layout.addWidget(self.btn_next)
        btn_layout.addStretch()
        
        layout.addLayout(btn_layout)

        # =========================================================
        # MEJORA: ATAJOS DE TECLADO GLOBALES PARA LA VENTANA
        # =========================================================
        self.shortcut_right = QShortcut(QKeySequence(Qt.Key_Right), self)
        self.shortcut_right.activated.connect(self.next_image)

        self.shortcut_left = QShortcut(QKeySequence(Qt.Key_Left), self)
        self.shortcut_left.activated.connect(self.prev_image)

    def cargar_imagen(self):
        if not self.archivos: return
        ruta = self.archivos[self.indice]
        self.scene.clear()
        if not os.path.exists(ruta):
            self.lbl_info.setText(f"NO ENCONTRADO: {os.path.basename(ruta)}")
            return
        pixmap = QPixmap(ruta)
        if pixmap.isNull():
            self.lbl_info.setText(f"ERROR DE FORMATO: {os.path.basename(ruta)}")
            return
        self.lbl_info.setText(f"DVMOA: {self.indice + 1}/{len(self.archivos)} - {os.path.basename(ruta)}")
        self.pixmap_item = QGraphicsPixmapItem(pixmap)
        self.scene.addItem(self.pixmap_item)
        self.ajustar_vista()

    def ajustar_vista(self):
        if hasattr(self, 'pixmap_item'):
            self.view.fitInView(self.pixmap_item, Qt.KeepAspectRatio)

    def next_image(self):
        self.indice = (self.indice + 1) % len(self.archivos)
        self.cargar_imagen()

    def prev_image(self):
        self.indice = (self.indice - 1) % len(self.archivos)
        self.cargar_imagen()

# ==========================================
# 3. CLASE PRINCIPAL DEL PLUGIN
# ==========================================
class VisorDVMOAPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.toolbar = None
        self.map_tool = None
        self.visor = None 
        self.dvmoa_menu = None # Variable para gestionar el menú superior

    def initGui(self):
        ruta_carpeta = os.path.join(os.path.dirname(__file__), "visor_plugin_carpeta.png")
        ruta_lupa = os.path.join(os.path.dirname(__file__), "visor_plugin_lupa.png")

        self.btn_folder = QAction(QIcon(ruta_carpeta), "Vincular Carpeta Fotos", self.iface.mainWindow())
        self.btn_folder.triggered.connect(self.set_folder)

        self.btn_tool = QAction(QIcon(ruta_lupa), "Herramienta Visor DVMOA", self.iface.mainWindow())
        self.btn_tool.setCheckable(True)
        self.btn_tool.triggered.connect(self.toggle_tool)

        # --- LÓGICA DE MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        # Revisamos si el menú "&DVMOA" ya fue creado por otra de tus herramientas
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si no existe, lo creamos
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        # Agregamos nuestras acciones a este menú principal
        self.dvmoa_menu.addAction(self.btn_folder)
        self.dvmoa_menu.addAction(self.btn_tool)

        self.toolbar = self.iface.addToolBar("DVMOA_VISOR")
        self.toolbar.setObjectName("DVMOAVisorToolbar")
        self.toolbar.addAction(self.btn_folder)
        self.toolbar.addAction(self.btn_tool)

        self.map_tool = QgsMapToolEmitPoint(self.canvas)
        self.map_tool.canvasClicked.connect(self.process_click)

    def unload(self):
        # Removemos las acciones del menú principal creado
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.btn_folder)
            self.dvmoa_menu.removeAction(self.btn_tool)
            # Si el menú se queda sin botones, lo eliminamos
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()

        if self.toolbar:
            self.iface.mainWindow().removeToolBar(self.toolbar)
        if self.visor:
            self.visor.close()

    def set_folder(self):
        folder = QFileDialog.getExistingDirectory(None, "SELECCIONA CARPETA DVMOA")
        if folder:
            QgsExpressionContextUtils.setProjectVariable(QgsProject.instance(), 'ruta_fotos', folder)
            self.iface.messageBar().pushMessage("DVMOA_VISOR", "Carpeta vinculada correctamente", level=0)

    def toggle_tool(self, checked):
        if checked:
            self.canvas.setMapTool(self.map_tool)
        else:
            self.iface.actionPan().trigger()

    def process_click(self, point, button):
        layer = self.iface.activeLayer()
        if not layer:
            self.iface.messageBar().pushMessage("DVMOA", "Selecciona una capa primero", level=1)
            return

        # 1. Encontrar el punto más cercano
        xform = QgsCoordinateTransform(self.canvas.mapSettings().destinationCrs(), layer.crs(), QgsProject.instance())
        punto_capa = xform.transform(point)
        search_rect = QgsGeometry.fromPointXY(punto_capa).buffer(self.canvas.mapSettings().mapUnitsPerPixel() * 40, 5).boundingBox()
        
        best_feature = None
        min_dist = float('inf')
        
        for feature in layer.getFeatures(QgsFeatureRequest().setFilterRect(search_rect)):
            dist = feature.geometry().distance(QgsGeometry.fromPointXY(punto_capa))
            if dist < min_dist:
                min_dist = dist
                best_feature = feature
        
        if not best_feature:
            self.iface.messageBar().pushMessage("DVMOA", "No hay puntos de fotos cerca del clic", level=0)
            return

        # 2. Búsqueda dinámica del nombre de la foto
        atributos = best_feature.attributes()
        campos = layer.fields().names()
        nombre_imagen = None
        exts_imagen = ('.jpg', '.jpeg', '.png', '.bmp', '.tif')

        # Estrategia A: Buscar por extensión
        for val in atributos:
            if val is not None:
                str_val = str(val).strip()
                if any(str_val.lower().endswith(ext) for ext in exts_imagen):
                    nombre_imagen = str_val
                    break
        
        # Estrategia B: Buscar por nombres comunes de columnas
        if not nombre_imagen:
            nombres_comunes = ['photo', 'foto', 'filename', 'name', 'nombre', 'filepath', 'id', 'clave', 'img', 'imagen']
            for i, nombre_campo in enumerate(campos):
                if any(comun in nombre_campo.lower() for comun in nombres_comunes):
                    val = str(atributos[i]).strip()
                    if val and val != "NULL":
                        nombre_imagen = val
                        break

        # Estrategia C: Tomar el primer atributo válido
        if not nombre_imagen:
            for val in atributos:
                if val is not None and str(val).strip() and str(val).strip() != "NULL":
                    nombre_imagen = str(val).strip()
                    break

        # 3. Enviar al visor
        if nombre_imagen:
            self.abrir_visor(nombre_imagen)
        else:
            self.iface.messageBar().pushMessage("ERROR", "El punto no contiene información válida para enlazar la foto.", level=2)

    def abrir_visor(self, filename):
        base_path = QgsExpressionContextUtils.projectScope(QgsProject.instance()).variable('ruta_fotos')
        if not base_path:
            self.iface.messageBar().pushMessage("ALERTA", "Vincula la carpeta primero (Boton Carpeta)", level=1)
            return

        archivo_objetivo = os.path.basename(filename).strip()
        exts = ('.jpg', '.jpeg', '.png', '.bmp', '.tif')
        
        try:
            todos = sorted([f for f in os.listdir(base_path) if f.lower().endswith(exts)])
        except Exception: 
            return

        match = None
        if archivo_objetivo in todos: 
            match = archivo_objetivo
        
        if not match:
            obj_lower = archivo_objetivo.lower()
            if not obj_lower.endswith(exts): 
                obj_lower += ".jpg"
            for f in todos:
                if f.lower() == obj_lower:
                    match = f
                    break
        
        if match:
            rutas = [os.path.join(base_path, f) for f in todos]
            if self.visor is None or not self.visor.isVisible():
                self.visor = VisorFotos(rutas, todos.index(match), self.iface.mainWindow())
                self.visor.show()
            else:
                self.visor.archivos = rutas
                self.visor.indice = todos.index(match)
                self.visor.cargar_imagen()
                self.visor.raise_()
                self.visor.activateWindow()
        else:
            self.iface.messageBar().pushMessage("NO ENCONTRADO", f"No se encontró la imagen: {archivo_objetivo}", level=2)