import os
import webbrowser
import socket
import subprocess
# Se agregó QMenu a la importación
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QInputDialog, QMenu 
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsProject, 
    QgsCoordinateReferenceSystem, 
    QgsCoordinateTransform
)
from qgis.gui import QgsMapToolIdentifyFeature

class Dvmoa3D:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.canvas = self.iface.mapCanvas()
        self.tool = None
        self.dvmoa_menu = None  # Variable para gestionar el menú superior
        
        # --- VARIABLE PARA RECORDAR EL MODELO ---
        self.modelo_seleccionado = None 

    def initGui(self):
        # --- AJUSTE DEL NOMBRE DEL ÍCONO ---
        icon_path = os.path.join(self.plugin_dir, 'dvmoa_3d.png')
        self.action = QAction(QIcon(icon_path), "3D DVMOA", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # --- LÓGICA DE MENÚ SUPERIOR ---
        menu_bar = self.iface.mainWindow().menuBar()
        
        # Revisamos si el menú "&DVMOA" ya fue creado por otra de tus herramientas
        for act in menu_bar.actions():
            if act.text() == "&DVMOA":
                self.dvmoa_menu = act.menu()
                break
                
        # Si no existe, lo creamos
        if not self.dvmoa_menu:
            self.dvmoa_menu = QMenu("&DVMOA", self.iface.mainWindow())
            menu_bar.addMenu(self.dvmoa_menu)
            
        # Agregamos nuestra acción a este menú principal
        self.dvmoa_menu.addAction(self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Removemos la acción del menú creado
        if self.dvmoa_menu:
            self.dvmoa_menu.removeAction(self.action)
            # Si el menú se queda sin botones, lo eliminamos
            if self.dvmoa_menu.isEmpty():
                self.dvmoa_menu.deleteLater()
                
        self.iface.removeToolBarIcon(self.action)
        if self.tool:
            self.canvas.unsetMapTool(self.tool)
        del self.action

    # ============================================
    # PROCESO PRINCIPAL
    # ============================================
    def run(self):
        capa = self.iface.activeLayer()
        
        if not capa or capa.geometryType() != 0:
            QMessageBox.warning(self.iface.mainWindow(), "Aviso", "Por favor, selecciona una capa de PUNTOS.")
            return

        # --- LÓGICA DE SELECCIÓN DE CARPETA (SOLO LA PRIMERA VEZ) ---
        if self.modelo_seleccionado is None:
            ruta_base_modelos = r"C:\DVMOA\VISOR_3D\Modelos"
            
            if os.path.exists(ruta_base_modelos):
                subcarpetas = [f for f in os.listdir(ruta_base_modelos) if os.path.isdir(os.path.join(ruta_base_modelos, f))]
                
                if subcarpetas:
                    item, ok = QInputDialog.getItem(
                        self.iface.mainWindow(), 
                        "Seleccionar Proyecto 3D", 
                        "¿Qué modelo desea cargar en esta sesión?", 
                        subcarpetas, 0, False
                    )
                    if ok and item:
                        self.modelo_seleccionado = f"Modelos/{item}/tileset.json"
                    else:
                        return # Cancelado por el usuario
                else:
                    QMessageBox.warning(self.iface.mainWindow(), "Aviso", "No hay subcarpetas en C:/DVMOA/VISOR_3D/Modelos")
                    return
            else:
                QMessageBox.warning(self.iface.mainWindow(), "Error", "No se encontró la carpeta C:/DVMOA/VISOR_3D/Modelos")
                return

        # --- DETECTAR Y ENCENDER SERVIDOR INVISIBLE ---
        puerto = 8000
        servidor_activo = False
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(('localhost', puerto)) == 0:
                servidor_activo = True

        if not servidor_activo:
            ruta_visor = r"C:\DVMOA\VISOR_3D" 
            ruta_bat = os.path.join(ruta_visor, "INICIAR_VISOR.bat")
            if os.path.exists(ruta_bat):
                try:
                    subprocess.Popen([ruta_bat], cwd=ruta_visor, creationflags=subprocess.CREATE_NO_WINDOW)
                    self.iface.messageBar().pushMessage("3D DVMOA", "Iniciando motor 3D...", level=0, duration=3)
                except Exception as e:
                    self.iface.messageBar().pushMessage("Error", f"Servidor: {e}", level=2)
                    return
            else:
                QMessageBox.warning(self.iface.mainWindow(), "Error", f"No se encontró {ruta_bat}")
                return

        # Herramienta de clic
        self.tool = QgsMapToolIdentifyFeature(self.canvas, capa)
        self.tool.featureIdentified.connect(self.al_hacer_clic)
        self.canvas.setMapTool(self.tool)
        
        # Mostrar mensaje con el modelo actual
        nombre_proyecto = self.modelo_seleccionado.split('/')[1]
        self.iface.messageBar().pushMessage(
            "3D DVMOA", 
            f"Modelo activo: {nombre_proyecto}. Haz clic en un punto.", 
            level=0, duration=5
        )

    def al_hacer_clic(self, feature):
        crs_origen = self.iface.activeLayer().crs()
        crs_destino = QgsCoordinateReferenceSystem("EPSG:4326")
        transformacion = QgsCoordinateTransform(crs_origen, crs_destino, QgsProject.instance())
        
        geom = feature.geometry()
        try:
            geom.transform(transformacion)
            punto = geom.asPoint()
            lon, lat = punto.x(), punto.y()
        except Exception as e:
            return

        # --- LA URL SE MANTIENE SIMPLE, CESIUM HACE EL RESTO ---
        url = f"http://localhost:8000/index.html?modelo={self.modelo_seleccionado}&lat={lat}&lon={lon}"
        
        try:
            webbrowser.open(url)
        except Exception as e:
            print(f"Error: {e}")