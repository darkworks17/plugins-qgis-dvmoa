def classFactory(iface):
    from .dvmoa_3d import Dvmoa3D
    return Dvmoa3D(iface)
